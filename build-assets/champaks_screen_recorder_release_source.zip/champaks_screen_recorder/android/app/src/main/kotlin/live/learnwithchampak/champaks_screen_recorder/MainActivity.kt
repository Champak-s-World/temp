package live.learnwithchampak.champaks_screen_recorder

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.net.Uri
import android.util.Size
import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "live.learnwithchampak.screenrecorder/recorder"
    private val eventsName = "live.learnwithchampak.screenrecorder/events"
    private val projectionRequest = 6111
    private val micRequest = 6112
    private val notificationRequest = 6113
    private var pendingStart: Map<String, Any?>? = null
    private var pendingResult: MethodChannel.Result? = null
    private var sink: EventChannel.EventSink? = null
    private val updates = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            sink?.success(mapOf("state" to (intent.getStringExtra("state") ?: "idle"),
                "message" to (intent.getStringExtra("message") ?: "")))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val filter = IntentFilter(ScreenRecorderService.EVENT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(updates, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(updates, filter)
    }

    override fun onDestroy() {
        unregisterReceiver(updates)
        super.onDestroy()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, eventsName).setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, eventSink: EventChannel.EventSink?) { sink = eventSink }
            override fun onCancel(arguments: Any?) { sink = null }
        })
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "start" -> {
                    if (ScreenRecorderService.state != "idle") { result.error("BUSY", "Recording is already active", null); return@setMethodCallHandler }
                    pendingStart = mapOf("microphone" to (call.argument<Boolean>("microphone") ?: true),
                        "quality" to (call.argument<String>("quality") ?: "1080p"),
                        "fps" to (call.argument<Int>("fps") ?: 30))
                    pendingResult = result
                    if (pendingStart!!["microphone"] == true && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
                    } else requestNotificationThenProjection()
                }
                "stop" -> { sendCommand(ScreenRecorderService.STOP); result.success(true) }
                "pause" -> { sendCommand(ScreenRecorderService.PAUSE); result.success(true) }
                "resume" -> { sendCommand(ScreenRecorderService.RESUME); result.success(true) }
                "status" -> result.success(mapOf("state" to ScreenRecorderService.state,
                    "startedAt" to ScreenRecorderService.startedAt))
                "list" -> result.success(listRecordings())
                "thumbnail" -> {
                    try {
                        val uri = Uri.parse(call.argument<String>("uri")!!)
                        val bitmap = contentResolver.loadThumbnail(uri, Size(240, 145), null)
                        val out = ByteArrayOutputStream()
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 75, out)
                        result.success(out.toByteArray())
                    } catch (e: Exception) { result.error("THUMB", e.message, null) }
                }
                "play" -> launchVideo(call.argument<String>("uri")!!, false, result)
                "share" -> launchVideo(call.argument<String>("uri")!!, true, result)
                "delete" -> {
                    try { result.success(contentResolver.delete(Uri.parse(call.argument<String>("uri")!!), null, null) > 0) }
                    catch (e: Exception) { result.error("DELETE", e.message, null) }
                }
                "rename" -> {
                    try {
                        val displayName = (call.argument<String>("name") ?: "Recording").trim()
                        if (displayName.isEmpty() || displayName.contains('/') || displayName.contains('\\')) { result.error("NAME", "Invalid filename", null); return@setMethodCallHandler }
                        val values = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, if (displayName.endsWith(".mp4", true)) displayName else "$displayName.mp4") }
                        result.success(contentResolver.update(Uri.parse(call.argument<String>("uri")!!), values, null, null) > 0)
                    } catch (e: Exception) { result.error("RENAME", e.message, null) }
                }
                "openAlarm" -> {
                    try {
                        val intent = packageManager.getLaunchIntentForPackage("live.learnwithchampak.champaks_alarm")
                        if (intent != null) { startActivity(intent); result.success(true) }
                        else result.error("NOT_INSTALLED", "Champak's Alarm is not installed", null)
                    } catch (e: Exception) { result.error("LAUNCH", e.message, null) }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun launchVideo(raw: String, share: Boolean, result: MethodChannel.Result) {
        try {
            val uri = Uri.parse(raw)
            val intent = if (share) Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, uri)
            } else Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "video/mp4") }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(if (share) Intent.createChooser(intent, "Share tutorial video") else intent)
            result.success(true)
        } catch (e: Exception) { result.error("VIEW", e.message, null) }
    }

    private fun listRecordings(): List<Map<String, Any?>> {
        val all = mutableListOf<Map<String, Any?>>()
        val columns = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_ADDED)
        contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, columns,
            "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?", arrayOf("Movies/ChampaksScreenRecorder/%"),
            "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                all.add(mapOf("uri" to ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id).toString(),
                    "name" to c.getString(1), "duration" to c.getLong(2), "size" to c.getLong(3),
                    "date" to c.getLong(4)))
            }
        }
        return all
    }

    private fun requestNotificationThenProjection() {
        // Notification permission is optional; Android's capture consent remains mandatory.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequest)
        } else requestProjection()
    }

    private fun requestProjection() {
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
        } catch (e: Exception) { finishStartWithError(e.message ?: "Cannot request screen recording") }
    }

    private fun finishStartWithError(message: String) {
        pendingResult?.error("START", message, null)
        pendingResult = null
        pendingStart = null
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micRequest) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) requestNotificationThenProjection()
            else finishStartWithError("Microphone permission denied. Turn off microphone to record video only.")
        } else if (requestCode == notificationRequest) {
            // A notification denial must never be treated as consent for screen capture.
            requestProjection()
        }
    }

    @Deprecated("MediaProjection consent uses the legacy result callback for FlutterActivity compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != projectionRequest) return
        if (resultCode != Activity.RESULT_OK || data == null) { finishStartWithError("Screen recording was not authorized"); return }
        try {
            val config = pendingStart ?: return
            val intent = Intent(this, ScreenRecorderService::class.java).apply {
                action = ScreenRecorderService.START
                putExtra("captureCode", resultCode)
                putExtra("captureIntent", data)
                putExtra("microphone", config["microphone"] as Boolean)
                putExtra("quality", config["quality"] as String)
                putExtra("fps", config["fps"] as Int)
            }
            startForegroundService(intent)
            pendingResult?.success(true)
            pendingResult = null
            pendingStart = null
        } catch (e: Exception) { finishStartWithError(e.message ?: "Failed to start foreground service") }
    }

    private fun sendCommand(command: String) {
        startService(Intent(this, ScreenRecorderService::class.java).apply { action = command })
    }
}
