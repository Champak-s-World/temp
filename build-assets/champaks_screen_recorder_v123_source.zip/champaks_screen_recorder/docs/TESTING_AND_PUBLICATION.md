# Release gate — do not roll out to production before verification

## Device acceptance tests
- [ ] Install release candidate from Play Internal Testing on Android 10, 13, 14, 15 and 16 (or available representative devices).
- [ ] Start 1080p/30 FPS screen capture, approve Android full-display consent, switch to Champak's Alarm, explain steps aloud, stop, and play saved MP4; confirm legible text and synchronized voice.
- [ ] Repeat with microphone off (no audio track) and 720p; verify media metadata and playback.
- [ ] Pause and resume, then play video to verify no corrupt frames or lost audio.
- [ ] Use notification Pause/Resume/Stop while another app is in foreground; deny notification permission and check app controls still stop safely.
- [ ] Deny microphone permission, cancel screen-capture permission, and repeat after denial; app must not capture anything.
- [ ] Stop with screen lock or system capture-control chip; verify MP4 is finalized or failed recording removed.
- [ ] Test screen rotation behavior: warn users to lock orientation until adaptive recording is implemented.
- [ ] Check storage-full, interruption by phone call, notification shades, incoming notifications, private content, and permission revocation.
- [ ] Verify MP4 is in Movies/ChampaksScreenRecorder, then playback, rename, deletion and Android share intent.
- [ ] Verify the app has no internet permission, ads, telemetry, or third-party SDK; confirm data-safety declarations are accurate.
- [ ] Verify launcher icon, app label, 64-bit support, target SDK 36, and in-app privacy text.
- [ ] Record in a quiet room and with a real alarm sounding; confirm mic behavior and user guidance.

## Publishing checklist
- [ ] Download offline upload-key signing kit; keep two backups. Never commit to GitHub or paste secrets in chat.
- [ ] Confirm signed AAB SHA-256 signer certificate matches newly generated upload key.
- [ ] Make a separate Google Play Console app with exact ID `live.learnwithchampak.champaks_screen_recorder`.
- [ ] Set app as free unless a separate business decision exists.
- [ ] Enable Google Play App Signing.
- [ ] Publish privacy policy HTML on a working public HTTPS URL; supply verified developer support email.
- [ ] Upload official 512x512 icon, 1024x500 feature graphic, and at least 2 screenshots captured from the actual app on a phone.
- [ ] Complete Data Safety, content rating, target audience, ads, app access, privacy and foreground-service declarations based on the actual release.
- [ ] Submit signed AAB to Internal Testing first, install it from Google Play and complete device tests.
- [ ] If the Google Play developer account is personal and created after Nov 13, 2023, meet its closed-testing requirement before production access (minimum 12 opted-in testers continuously for 14 days, as per current Play Console rules).
- [ ] Confirm crash-free testing, user consent, and App Bundle Explorer warnings resolved; then request approval for production rollout.

## Known limitations of 1.0
No internal app-audio capture, floating overlay, camera bubble, touch indicators, auto chaptering, editing or annotation. Do not advertise unsupported features.


### 1.2.3 regression checks
1. Allow overlay permission; start recorder. After permission consent, check that the app remains in front with a blocked progress panel until the REC toolbar is fully laid out. If window creation is delayed, no video is started. Cancel works.
2. Try temporarily revoking overlay permission. Recorder must not proceed invisibly and must not save a blank video.
3. On Android 14+, verify the capture permission asks to share **entire display** (OEM behavior can differ); open Facebook, its search window, a separate app, notifications and a popup menu. Check that these appear during MP4 playback.
4. Verify secure windows (FLAG_SECURE, DRM) may be intentionally blank. Do not attempt to bypass Android protection.
5. Verify annotations, microphone, Pause/Resume, Stop & Save, and MediaStore location.
