# Champak's Screen Recorder v1.2.5 — Device acceptance tests

## Important

This build requires **real-phone testing**. Kotlin/Dart compilation cannot prove toolbar removal, perfect frame recovery, or capture of external windows. Do not publish to production before reviewing recorded MP4s.

## Full display — safe crop (default)

1. On Android 14+, select **Entire display**, quality 720p/30 FPS and **Safe edge crop**. Allow screen capture and overlay access.
2. Set toolbar **Top, expanded**. Open a changing app screen and draw a circle and arrow.
3. Replay MP4: no black video, no REC control pixels, annotations visible. Verify top edge of the app is cropped and content is scaled.
4. Tap **LESS** to collapse, then **MORE** to expand. REC/Stop must remain usable.
5. Tap **BOTTOM** to dock at bottom. Verify subsequent frames exclude controls; some bottom content is cropped.
6. Tap Pause/Resume and Stop & Save. Ensure audio/video synchronized and the video appears in Library.
7. Switch to Facebook, open search, search a term and review the MP4. New windows appear only where Android permits.

## App selection

1. Choose **Selected app** on Android 14+. Approve Android picker choosing one target app.
2. Verify clean target-app recording, annotations and floating controls still usable on the phone.
3. Open another app: it must not be claimed as being recorded. This is by design.
4. If Android offers or selects Entire display instead, switch to full-display Safe edge crop in the app.

## Experimental smart repair

1. Choose **Smart repair (experimental)**. Begin with toolbar docked TOP.
2. Switch to BOTTOM. For a short interval, the compositor can reuse clean pixels from previous frames.
3. Verify no black video. Recently changed app content under controls can look stale.
4. Observe fallback to crop after the cache ages out. For publication, prefer Safe crop.

## Privacy restrictions

- A secure app/DRM video may blank its protected content; do not attempt to bypass protection.
- Avoid recording passwords, notifications and sensitive dialogs.
- Check output on a real Android 13/14/15/16 device if available.
