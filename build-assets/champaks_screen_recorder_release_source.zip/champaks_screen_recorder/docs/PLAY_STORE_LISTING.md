# Google Play listing — Champak's Screen Recorder

## App name
Champak's Screen Recorder

## Short description (under 80 characters)
Record Android screen tutorials with optional voice narration. Save and share MP4s.

## Full description
Create clear Android software tutorials using Champak's Screen Recorder. Capture your phone's screen, explain each step with optional microphone narration, and save the result as an MP4 video on your device.

Designed for educators, students, software trainers and anyone demonstrating how to use an Android application.

Features in version 1.0:
- Record your Android screen after approving the Android screen-capture prompt.
- Choose 720p or 1080p and 24, 30 or 60 FPS, depending on device capabilities.
- Include spoken microphone narration or record video without audio.
- Pause, resume and stop a recording with convenient recording controls.
- Keep recordings in your phone's Movies folder.
- Browse, play, rename, delete and share recordings from the built-in library.
- Follow the in-app tutorial guide for showing how an Android application works.
- No account required; no automatic uploads or in-app advertising.

Android asks for screen-capture approval for each recording. Some apps protect their content against capture. Recording resolution and frame rate depend on device support, and recordings stay on the phone unless you choose to share them.

Developed and maintained by Champak Roy.

## Store settings to review
- Category: Productivity (proposed)
- Ads: No (subject to final build verification)
- Target audience: General audience, not designed primarily for children
- App access: All features available without login
- Data Safety: Based on local-only functionality, no developer-side data collection or sharing. Verify final APK/AAB and linked services before submitting.
- Foreground service declaration: mediaProjection (screen recording) and microphone (voice narration); provide video demonstrating the recording consent + notification stop controls.
- Privacy policy: publish `docs/PRIVACY_POLICY.html` at a public HTTPS URL and enter that URL in Play Console.
- Contact email: REQUIRED from developer; not yet supplied.
- Screenshots: REQUIRED: capture from the actual installed app. Generated concept mockups are not valid replacements.

## Release name
1.0.0 — Teaching Edition

## What's new (English)
First release: record software demonstrations with optional microphone narration, pause/resume controls, MP4 saving and a local recordings library. Includes a guide for making Android app tutorials.
