# Champak's Screen Recorder — Teaching Edition 1.2.2

Flutter UI + native Kotlin Android MediaProjection recorder for narrating app demonstrations, including Champak's Alarm.

## Functional scope in 1.1.0 source

- Android 10+ device with Android 16 / target API 36 configuration
- One-time, explicit Android screen-capture consent **for each recording**
- 720p / 1080p target resolutions, 24/30/60 FPS (subject to device encoders)
- Optional microphone voice-over; foreground service and notification controls
- Pause / Resume / Stop; export MP4 through MediaStore
- Library: preview in installed video player, native thumbnails, rename, share, delete
- Step-by-step teaching guide, one-tap shortcut to Champak's Alarm if installed
- No Internet permission, ads SDK, user accounts, or cloud uploads

**Implemented in 1.2.0:** A compulsory red floating REC toolbar (timer, pause/resume,
stop/save) stays on top during every active recording and pause. A second row offers
Pen, Circle, Arrow, Clear and Done; Done restores normal interaction without hiding
the toolbar. The toolbar can be dragged vertically but not collapsed or dismissed
until recording stops. Android's **Draw over other apps** permission must be granted;
recording is blocked if the toolbar is unavailable, rather than silently continuing.
Android can temporarily suppress third-party overlays on protected system surfaces,
permission screens, or secure applications. If the toolbar is removed during a
session, the service ends the recording to avoid an invisible recording session.

**Not yet supported:** internal app audio, automatic tap visualization without
Android's manually enabled Show taps system setting, selfie camera or video editing.
Some secure apps intentionally suppress screen capture. Lock orientation during a
recording; rotation changes are not fully handled.

This source is a **release candidate**, not an on-device-validated Google Play release. Android devices still need on-device testing. Debug APK build requires Flutter + Android SDK; do not submit a debug APK to Play.

## Build on a developer machine

1. Install Flutter stable and Android SDK with Platform 36, build-tools and JDK 17.
2. Run `bash scripts/prepare_android.sh` from this directory (requires Flutter).
3. Run `flutter doctor`, `flutter pub get`, then `flutter build apk --debug`.
4. APK: `build/app/outputs/flutter-apk/app-debug.apk`.
5. Test an actual Android device; emulator support varies.

You can also use `.github/workflows/screenrecorder-apk.yml` as a GitHub Actions recipe: it provisions Flutter and builds a **debug** APK artifact (copy it with your source to an isolated repository). It does not expose signing secrets.

## Final publication gates (not performed here)

1. Test Android 10–16 (capture consent, app-only capture, screen-off, rotation, calls, permission denial).
2. Replace generated Flutter launcher icon and prepare Play graphics/screenshots.
3. Configure dedicated, securely stored Play upload keystore. Never commit signing keys or passwords.
4. Configure release signing; create a signed `flutter build appbundle --release` and verify with `jarsigner` / Play Console.
5. Complete Play Console declarations, notably foreground service, microphone, privacy/data-safety and policies.
6. Disclose that protected app content may not be captured and microphone audio is retained locally.

**Package ID:** `live.learnwithchampak.champaks_screen_recorder`

Developed and maintained by Champak Roy.

## Google Play release candidate assets
- `branding/play-icon-512.png` and `branding/feature-graphic-1024x500.png`: final-size Play graphics; launcher bitmaps are injected by `scripts/prepare_android.sh`.
- `docs/PLAY_STORE_LISTING.md`: accurate first-release listing text.
- `docs/PRIVACY_POLICY.html`: publish as a public HTTPS privacy-policy page before Play submission.
- `docs/TESTING_AND_PUBLICATION.md`: mandatory device and disclosure checklist.
- `docs/UPLOAD_SIGNING_INSTRUCTIONS.md`: signing the unsigned AAB locally with a private upload key.
- The CI workflow for an **unsigned release AAB** keeps the upload key entirely off GitHub. Signing is done offline.

Do **not** publish to production until the signed bundle is installed from Play Internal Testing and essential recording / video-save functions are verified on actual devices.

## Changes in 1.1.0 (build 2)

- Automatically returns to the Android Home screen **after** foreground recording actually starts; can be disabled in options.
- Saved-video notifications link to Library and show the complete Files location: Internal storage > Movies > ChampaksScreenRecorder.
- A dedicated Show taps help button opens Android Developer options; the user turns on the built-in system tap indicator. No accessibility monitoring or elevated settings permission.
- Optional floating teaching toolbar: pen, circle, arrow, clear, stop; **Done** switches to pass-through mode so users can interact with the demonstrated app. Requires separate Android Draw over other apps approval. Choose Entire screen in the MediaProjection picker for the toolbar to appear in the video.

New required Android special access for recording: SYSTEM_ALERT_WINDOW (Draw over other apps). Always confirm app switching, drawing, pause and save on Android 10–16 devices before publishing.

## Changes in 1.2.0 (build 3)

- The floating toolbar is now **mandatory** for each recording; permission must be granted before pressing Start.
- Clear, high-contrast **RED REC + elapsed timer**, blue **PAUSE/RESUME** and red **STOP & SAVE** controls.
- Pen, Circle, Arrow, Clear and Done are always visible, even when drawing mode is inactive.
- Toolbar cannot be hidden, collapsed or dismissed while recording. Drag handle moves it vertically.
- Recording does not start if overlay creation fails; an on-device watchdog ends the session if the overlay disappears.
- On pause the toolbar displays PAUSED, and stays visible. On stop it is removed and the recording is saved to Library.
- Android system policy can temporarily hide overlays in restricted surfaces; guarantee applies to ordinary compatible app screens.
- Play publication: new AAB requires versionCode 3 and disclosure of required overlay access, then real-device internal testing.


## v1.2.1 (build 4) — fix missing toolbar at startup

- Fixes an Android WindowManager attachment timing bug that caused an immediate
  false-negative `isAttachedToWindow` check after `addView` and the message
  “Floating recording toolbar could not be shown.”
- Starts actual video capture **only after** the mandatory toolbar attaches to the
  window, using a bounded 2.5-second asynchronous attachment check.
- If an overlay is denied or never attaches, recording aborts with a specific
  error and does not leave an invalid MP4.
- The toolbar remains visible while the recording is active; Android may hide
  third-party overlays on protected system screens.
- Verify on a physical Android phone including app switch, Done, Pause, Resume.

## Changes in 1.2.2 (build 5) — annotations burned into the MP4

- Fix: screen annotations were visible in a floating window but absent from the video because the Android MediaProjection → MediaRecorder path did not composite TYPE_APPLICATION_OVERLAY windows.
- The recorder now uses a dedicated EGL/OpenGL ES2 compositor: MediaProjection → SurfaceTexture → screen + vector-mark bitmap → MediaRecorder input Surface → H.264 MP4.
- Pen, circle, and arrow marks (including active strokes) are rendered to video frames, independent of whether Android captures overlays.
- Clear removes marks from subsequent frames but does not retroactively change previous footage. Previously saved MP4 files cannot be repaired by this update; only recordings made with v1.2.2 include the new compositing pathway.
- The floating toolbar remains mandatory and visible on the device; the video compositor deliberately burns the annotations into the output, not the full recording-control toolbar.
- Rendering needs graphics/GPU resources; validate on real Android phones, especially audio synchronization, full-screen capture selection, portrait/landscape alignment, pause/resume and performance at 1080p/60FPS.

**Do not upload to Play production until a real-device recording has been replayed and the marks confirmed inside the resulting MP4.**
