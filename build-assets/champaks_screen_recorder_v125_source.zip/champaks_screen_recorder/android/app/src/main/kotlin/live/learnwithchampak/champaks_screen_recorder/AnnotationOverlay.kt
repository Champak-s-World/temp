package live.learnwithchampak.champaks_screen_recorder

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Persistent controls with a TOP/BOTTOM dock and a collapsible layout.
 * The compact header ALWAYS retains REC/time, Pause/Resume and Stop & Save.
 * The toolbar is intentionally NOT FLAG_SECURE: that made entire videos black
 * on some Android devices. Its docked screen strip is removed by the encoder
 * compositor (lossless clean-source repair where available; safe crop otherwise).
 * Pen, circle and arrow strokes are independently burned into MP4 frames.
 */
class AnnotationOverlay(
    private val context: Context,
    private val onStop: () -> Unit,
    private val onPauseResume: () -> Unit,
    private val onAnnotationsChanged: () -> Unit,
    private val initialDock: String = "top",
    private val initiallyCollapsed: Boolean = false,
    private val onToolbarBoundsChanged: (Int, Int, String) -> Unit = { _, _, _ -> },
    private val onToolbarMoving: () -> Unit = {},
    private val onToolbarSettled: () -> Unit = {}
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val density = context.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density + 0.5f).toInt()
    private val drawingLayer = DrawingLayer(context) { onAnnotationsChanged() }
    private var shown = false
    private var isDrawing = false
    private var paused = false
    private var startedAt = 0L
    private var pausedAt = 0L
    private var pausedDuration = 0L
    private var selectedTool = DrawingLayer.Tool.PEN
    private var dock = if (initialDock == "bottom") "bottom" else "top"
    private var collapsed = initiallyCollapsed
    private var transitionGeneration = 0
    private lateinit var expandedRow: LinearLayout
    private lateinit var toolsRow: LinearLayout
    private lateinit var miniPause: TextView
    private lateinit var miniStop: TextView
    private lateinit var collapseButton: TextView
    private lateinit var dockButton: TextView
    private lateinit var toolbar: LinearLayout
    private lateinit var toolbarParams: WindowManager.LayoutParams
    private lateinit var canvasParams: WindowManager.LayoutParams
    private lateinit var recordingLabel: TextView
    private lateinit var pauseButton: TextView
    private lateinit var doneButton: TextView
    private lateinit var instruction: TextView
    private val toolButtons = mutableMapOf<DrawingLayer.Tool, TextView>()

    private val tick = object : Runnable {
        override fun run() {
            if (!shown) return
            val now = if (paused) pausedAt else SystemClock.elapsedRealtime()
            val seconds = ((now - startedAt - pausedDuration).coerceAtLeast(0L) / 1000L)
            val time = "%02d:%02d:%02d".format(seconds / 3600, (seconds / 60) % 60, seconds % 60)
            recordingLabel.text = if (paused) "❚❚ PAUSED  $time" else "● REC  $time"
            main.postDelayed(this, 1000L)
        }
    }

    private fun background(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun button(label: String, color: Int, action: () -> Unit): TextView = TextView(context).apply {
        text = label
        textSize = 12f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        minHeight = dp(42)
        setPadding(dp(2), dp(3), dp(2), dp(3))
        background = background(color, 9)
        setOnClickListener { action() }
        contentDescription = label
    }

    private fun weighted(row: LinearLayout, child: TextView, margin: Int = 3) {
        row.addView(child, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
            marginEnd = dp(margin)
        })
    }

    fun show() {
        if (shown) return
        require(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { "Android 8+ overlays required" }
        val base = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        canvasParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            base or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            alpha = 0.65f // Android 12+ touch-through obscuring-opacity cap is 0.8.
        }

        val width = (context.resources.displayMetrics.widthPixels - dp(16)).coerceAtLeast(dp(260))
        // Do NOT use FLAG_SECURE: it causes black/blank recorded regions on many
        // devices. The encoder handles removal, not Android's secure-window flag.
        toolbarParams = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            base, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(65)
        }

        toolbar = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7), dp(7), dp(5), dp(7))
            background = background(Color.rgb(11, 27, 45), 14)
            elevation = dp(14).toFloat()
            // Make this discoverable by TalkBack as a distinct persistent recording panel.
            contentDescription = "Recording in progress. Persistent screen recorder controls"
        }
        // Compact mode deliberately keeps both essential recording actions in
        // the first row. Expanded mode shows larger copies plus teaching tools.
        val heading = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        recordingLabel = TextView(context).apply {
            text = "● REC  00:00:00"
            setTextColor(Color.WHITE)
            background = background(Color.rgb(208, 25, 41), 8)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(6), dp(3), dp(6))
        }
        heading.addView(recordingLabel, LinearLayout.LayoutParams(0, dp(40), 2.5f))
        dockButton = button(if (dock == "top") "⇣ BOTTOM" else "⇡ TOP",
            Color.rgb(32, 83, 131)) { setDock(if (dock == "top") "bottom" else "top") }
        heading.addView(dockButton, LinearLayout.LayoutParams(0, dp(40), 1.7f).apply { marginStart = dp(3) })
        collapseButton = button(if (collapsed) "▣ MORE" else "▴ LESS", Color.rgb(42,72,108)) {
            beginTransition()
            // Collapsing must restore normal taps to the demonstrated app.
            // Otherwise the invisible drawing canvas keeps intercepting input
            // while DONE is hidden in compact mode.
            if (!collapsed && isDrawing) setDrawing(false)
            collapsed = !collapsed
            applyCollapsedState()
        }
        heading.addView(collapseButton, LinearLayout.LayoutParams(0, dp(40), 1.3f).apply { marginStart = dp(3) })
        miniPause = button("❚❚", Color.rgb(48,98,165)) { onPauseResume() }.apply {
            contentDescription = "Pause or resume recording"
        }
        heading.addView(miniPause, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(3) })
        miniStop = button("■", Color.rgb(197,26,39)) { onStop() }.apply {
            contentDescription = "Stop recording and save video"
        }
        heading.addView(miniStop, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(3) })
        toolbar.addView(heading)

        expandedRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(5), 0, dp(3))
        }
        pauseButton = button("❚❚  PAUSE", Color.rgb(48,98,165)) { onPauseResume() }
        weighted(expandedRow, pauseButton)
        weighted(expandedRow, button("■  STOP & SAVE", Color.rgb(197,26,39)) { onStop() })
        toolbar.addView(expandedRow)

        toolsRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        fun tool(t: DrawingLayer.Tool, name: String): TextView {
            val view = button(name, Color.rgb(42,72,108)) { select(t) }
            toolButtons[t] = view
            weighted(toolsRow, view, 2)
            return view
        }
        tool(DrawingLayer.Tool.PEN, "✎ PEN")
        tool(DrawingLayer.Tool.CIRCLE, "○ CIRCLE")
        tool(DrawingLayer.Tool.ARROW, "➜ ARROW")
        weighted(toolsRow, button("⌫ CLEAR", Color.rgb(42,72,108)) { drawingLayer.clear() }, 2)
        doneButton = button("✓ DONE", Color.rgb(25,124,78)) { setDrawing(false) }
        weighted(toolsRow, doneButton, 0)
        toolbar.addView(toolsRow)
        instruction = TextView(context).apply {
            text = "Pen / Circle / Arrow: saved to MP4. DONE = use app."
            setTextColor(Color.rgb(230,239,253))
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(5), dp(4), 0)
        }
        toolbar.addView(instruction)
        applyCollapsedState()
        toolbar.addOnLayoutChangeListener { _, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            if (right-left != oldRight-oldLeft || bottom-top != oldBottom-oldTop) {
                main.post { if (shown) positionToolbar() }
            }
        }
        try {
            wm.addView(drawingLayer, canvasParams)
            wm.addView(toolbar, toolbarParams)
            shown = true
            startedAt = SystemClock.elapsedRealtime()
            paused = false
            refreshButtons()
            main.post(tick)
            main.post { if (shown) positionToolbar() }
        } catch (e: Exception) {
            try { wm.removeViewImmediate(toolbar) } catch (_: Exception) {}
            try { wm.removeViewImmediate(drawingLayer) } catch (_: Exception) {}
            shown = false
            main.removeCallbacks(tick)
            throw e
        }
    }

    /**
     * WindowManager.addView() is asynchronous.  A window can be *attached* but
     * not yet laid out or drawn, especially after the MediaProjection dialog.
     * Require a window token, visibility and nonzero geometry before the service
     * can consider it ready.  The service also requires several stable polls.
     */
    fun isReadyToRecord(): Boolean = shown && toolbar.isAttachedToWindow &&
        toolbar.windowToken != null && toolbar.isShown &&
        toolbar.width >= dp(240) && toolbar.height >= dp(40)

    // Same guarantee for the recording watchdog: never silently lose controls.
    fun isVisible(): Boolean = isReadyToRecord()

    private fun applyCollapsedState() {
        if (!::expandedRow.isInitialized) return
        expandedRow.visibility = if (collapsed) View.GONE else View.VISIBLE
        toolsRow.visibility = if (collapsed) View.GONE else View.VISIBLE
        instruction.visibility = if (collapsed) View.GONE else View.VISIBLE
        miniPause.visibility = if (collapsed) View.VISIBLE else View.GONE
        miniStop.visibility = if (collapsed) View.VISIBLE else View.GONE
        collapseButton.text = if (collapsed) "▣ MORE" else "▴ LESS"
        if (shown) main.post { positionToolbar() }
    }

    private fun setDock(next: String) {
        beginTransition()
        dock = if (next == "bottom") "bottom" else "top"
        dockButton.text = if (dock == "top") "⇣ BOTTOM" else "⇡ TOP"
        positionToolbar()
    }

    private fun beginTransition() {
        if (!shown) return
        val generation = ++transitionGeneration
        onToolbarMoving() // suspend recording frames before a controls move or resize
        main.postDelayed({
            if (shown && generation == transitionGeneration) {
                positionToolbar()
                onToolbarSettled()
            }
        }, 350L)
    }

    private fun positionToolbar() {
        if (!shown || !toolbar.isAttachedToWindow) return
        val physical = Point()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealSize(physical)
        val targetY = if (dock == "bottom")
            (physical.y - toolbar.height - dp(80)).coerceAtLeast(dp(60))
            else dp(60)
        if (toolbarParams.y != targetY) {
            toolbarParams.y = targetY
            try { wm.updateViewLayout(toolbar, toolbarParams) } catch (_: Exception) {}
        }
        val location = IntArray(2)
        toolbar.getLocationOnScreen(location)
        // A FULL-WIDTH edge crop covers the control window regardless of x.
        val margin = dp(8)
        val topStrip = if (dock == "top")
            (location[1] + toolbar.height + margin).coerceIn(0, physical.y / 2)
            else 0
        val bottomStrip = if (dock == "bottom")
            (physical.y - location[1] + margin).coerceIn(0, physical.y / 2)
            else 0
        onToolbarBoundsChanged(topStrip, bottomStrip, dock)
    }

    /** Start the REC timer at the same time the actual encoder starts. */
    fun markRecordingStarted() {
        if (!shown) return
        startedAt = SystemClock.elapsedRealtime()
        pausedDuration = 0L
        paused = false
        main.removeCallbacks(tick)
        main.post(tick)
    }

    fun setPaused(value: Boolean) {
        if (!shown || paused == value) return
        val now = SystemClock.elapsedRealtime()
        if (value) pausedAt = now else pausedDuration += now - pausedAt
        paused = value
        pauseButton.text = if (paused) "▶  RESUME" else "❚❚  PAUSE"
        miniPause.text = if (paused) "▶" else "❚❚"
        recordingLabel.background = background(
            if (paused) Color.rgb(180, 117, 8) else Color.rgb(208, 25, 41), 8)
        main.removeCallbacks(tick)
        main.post(tick)
    }

    private fun select(t: DrawingLayer.Tool) {
        selectedTool = t
        drawingLayer.tool = t
        setDrawing(true)
    }

    private fun setDrawing(value: Boolean) {
        if (!shown) return
        isDrawing = value
        canvasParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            (if (isDrawing) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        canvasParams.alpha = if (isDrawing) 1f else 0.65f
        wm.updateViewLayout(drawingLayer, canvasParams)
        refreshButtons()
    }

    private fun refreshButtons() {
        if (!shown) return
        toolButtons.forEach { (t, view) ->
            view.background = background(
                if (isDrawing && t == selectedTool) Color.rgb(7, 112, 195) else Color.rgb(42, 72, 108), 9)
        }
        doneButton.background = background(
            if (isDrawing) Color.rgb(25, 154, 90) else Color.rgb(27, 76, 59), 9)
        instruction.text = if (isDrawing) "DRAWING MODE • DONE returns to the app" else
            "TOP/BOTTOM chooses dock • LESS collapses (REC and STOP stay visible)"
    }

    /** Renders only pen/circle/arrow marks, not the recording controls, into the video. */
    fun snapshotAnnotations(videoWidth: Int, videoHeight: Int): Bitmap {
        val result = Bitmap.createBitmap(videoWidth, videoHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val sourceWidth = drawingLayer.width.coerceAtLeast(1)
        val sourceHeight = drawingLayer.height.coerceAtLeast(1)
        canvas.scale(videoWidth.toFloat() / sourceWidth, videoHeight.toFloat() / sourceHeight)
        drawingLayer.renderMarks(canvas)
        return result
    }

    fun dismiss() {
        if (!shown) return
        shown = false
        main.removeCallbacks(tick)
        try { wm.removeViewImmediate(toolbar) } catch (_: Exception) {}
        try { wm.removeViewImmediate(drawingLayer) } catch (_: Exception) {}
    }

    private class DrawingLayer(context: Context, private val onChanged: () -> Unit) : View(context) {
        enum class Tool { PEN, CIRCLE, ARROW }
        data class Mark(val tool: Tool, val start: PointF, var end: PointF, val path: Path)
        var tool = Tool.PEN
        private val marks = mutableListOf<Mark>()
        private var active: Mark? = null
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        fun clear() { marks.clear(); active = null; invalidate(); onChanged() }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            val p = PointF(e.x, e.y)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    active = Mark(tool, p, PointF(p.x, p.y), Path().apply { moveTo(p.x, p.y) })
                    invalidate()
                    onChanged()
                    return true
                }
                MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                    active?.let {
                        it.end = p
                        if (it.tool == Tool.PEN) it.path.lineTo(p.x, p.y)
                        if (e.actionMasked == MotionEvent.ACTION_UP) {
                            marks.add(it)
                            active = null
                        }
                    }
                    invalidate()
                    onChanged()
                    return true
                }
            }
            return true
        }
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            renderMarks(c)
        }
        fun renderMarks(c: Canvas) {
            marks.forEach { drawMark(c, it) }
            active?.let { drawMark(c, it) }
        }
        private fun drawMark(c: Canvas, mark: Mark) {
            stroke.color = Color.BLACK
            stroke.strokeWidth = 10f * resources.displayMetrics.density
            paintMark(c, mark)
            stroke.color = Color.YELLOW
            stroke.strokeWidth = 5f * resources.displayMetrics.density
            paintMark(c, mark)
        }
        private fun paintMark(c: Canvas, mark: Mark) {
            when (mark.tool) {
                Tool.PEN -> c.drawPath(mark.path, stroke)
                Tool.CIRCLE -> c.drawOval(RectF(
                    minOf(mark.start.x, mark.end.x), minOf(mark.start.y, mark.end.y),
                    maxOf(mark.start.x, mark.end.x), maxOf(mark.start.y, mark.end.y)), stroke)
                Tool.ARROW -> {
                    val a = mark.start
                    val b = mark.end
                    c.drawLine(a.x, a.y, b.x, b.y, stroke)
                    val angle = atan2((b.y - a.y).toDouble(), (b.x - a.x).toDouble())
                    val len = 20f * resources.displayMetrics.density
                    val left = angle + 2.55
                    val right = angle - 2.55
                    c.drawLine(b.x, b.y, b.x + len * cos(left).toFloat(), b.y + len * sin(left).toFloat(), stroke)
                    c.drawLine(b.x, b.y, b.x + len * cos(right).toFloat(), b.y + len * sin(right).toFloat(), stroke)
                }
            }
        }
    }
}
