# Champak's Screen Recorder — Teaching Edition 1.1.0

Flutter UI + native Kotlin Android MediaProjection recorder for narrating app demonstrations, including Champak's Alarm.

## Functional scope in 1.1.0 source

- Android 10+ device with Android 16 / target API 36 configuration
- One-time, explicit Android screen-capture consent **for each recording**
- 720p / 1080p target resolutions, 24/30/60 FPS (subject to device encoders)
- Optional microphone voice-over; foreground service and notification controls
- Pause / Resume / Stop; export MP4 through MediaStore
- Library: preview in installed video player, native thumbnails, rename, share, delete
- Step-by-step teaching guide, one-tap shortcut to Champak's Alarm if installed
- No Internet permission, ads SDK, user accounts, or cloud uploads

**Not yet supported:** recording internal app audio, tap visualization while using other apps, annotation overlay, selfie camera, or editing. These are later milestones. Some secure apps intentionally suppress screen capture. Rotation changes while recording are not fully handled in this version: lock orientation before starting.

This source is a **release candidate**, not an on-device-validated Google Play release. Android devices still need on-device testing. Debug APK build requires Flutter + Android SDK; do not submit a debug APK to Play.

## Build on a developer machine

1. Install Flutter stable and Android SDK with Platform 36, build-tools and JDK 17.
2. Run `bash scripts/prepare_android.sh` from this directory (requires Flutter).
3. Run `flutter doctor`, `flutter pub get`, then `flutter build apk --debug`.
4. APK: `build/app/outputs/flutter-apk/app-debug.apk`.
5. Test an actual Android device; emulator support varies.

You can also use `.github/workflows/screenrecorder-apk.yml` as a GitHub Actions recipe: it provisions Flutter and builds a **debug** APK artifact (copy it with your source to an isolated repository). It does not expose signing secrets.

## Final publication gates (not performed here)

1. Test Android 10–16 (capture consent, app-only capture, screen-off, rotation, calls, permission denial).
2. Replace generated Flutter launcher icon and prepare Play graphics/screenshots.
3. Configure dedicated, securely stored Play upload keystore. Never commit signing keys or passwords.
4. Configure release signing; create a signed `flutter build appbundle --release` and verify with `jarsigner` / Play Console.
5. Complete Play Console declarations, notably foreground service, microphone, privacy/data-safety and policies.
6. Disclose that protected app content may not be captured and microphone audio is retained locally.

**Package ID:** `live.learnwithchampak.champaks_screen_recorder`

Developed and maintained by Champak Roy.

## Google Play release candidate assets
- `branding/play-icon-512.png` and `branding/feature-graphic-1024x500.png`: final-size Play graphics; launcher bitmaps are injected by `scripts/prepare_android.sh`.
- `docs/PLAY_STORE_LISTING.md`: accurate first-release listing text.
- `docs/PRIVACY_POLICY.html`: publish as a public HTTPS privacy-policy page before Play submission.
- `docs/TESTING_AND_PUBLICATION.md`: mandatory device and disclosure checklist.
- `docs/UPLOAD_SIGNING_INSTRUCTIONS.md`: signing the unsigned AAB locally with a private upload key.
- The CI workflow for an **unsigned release AAB** keeps the upload key entirely off GitHub. Signing is done offline.

Do **not** publish to production until the signed bundle is installed from Play Internal Testing and essential recording / video-save functions are verified on actual devices.

## Changes in 1.1.0 (build 2)

- Automatically returns to the Android Home screen **after** foreground recording actually starts; can be disabled in options.
- Saved-video notifications link to Library and show the complete Files location: Internal storage > Movies > ChampaksScreenRecorder.
- A dedicated Show taps help button opens Android Developer options; the user turns on the built-in system tap indicator. No accessibility monitoring or elevated settings permission.
- Optional floating teaching toolbar: pen, circle, arrow, clear, stop; **Done** switches to pass-through mode so users can interact with the demonstrated app. Requires separate Android Draw over other apps approval. Choose Entire screen in the MediaProjection picker for the toolbar to appear in the video.

New optional Android permission: SYSTEM_ALERT_WINDOW (only for drawings); otherwise the app works without it. Always confirm app switching, drawing, pause and save on Android 10–16 devices before publishing.
