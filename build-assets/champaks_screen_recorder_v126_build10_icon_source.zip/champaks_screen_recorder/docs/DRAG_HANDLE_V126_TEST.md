# Champak’s Screen Recorder v1.2.6 — permanent drag-handle acceptance

1. Choose **Entire Display / Safe edge crop / Top / Start collapsed**.
2. Start recording. Confirm the turquoise **⠿ DRAG TOOLBAR ↕** button
   appears in compact view along with REC, Pause and Stop.
3. Press and HOLD the drag button; move to the bottom of the screen.
   The toolbar follows your finger and snaps to bottom when released.
4. Press MORE; confirm the drag button is still visible. Draw a circle and
   arrow. Press DONE. Press LESS and confirm the drag button remains visible.
5. Drag the toolbar back to top. Tap the handle once: it should swap edge.
6. Pause and resume, ensuring the drag handle remains visible and usable.
7. Stop and replay the MP4: circles and arrows must be encoded; no full
   black screen and no visible docked toolbar in the video. Safe crop omits a
   narrow top or bottom strip, and dragging may hold a few frames.
8. Repeat with **Smart repair (experimental)** and **Selected App** mode,
   noting some app windows and secure content are restricted by Android.
