# Verify annotation recording on a real Android phone (v1.2.2)

1. Install v1.2.2 build 5. Enable **Display over other apps** and microphone if desired.
2. Choose 720p / 30 FPS initially for a low-overhead test, then 1080p / 30 FPS.
3. Start recording, choose **Entire screen**, and open Champak's Alarm.
4. Select PEN and draw a yellow zigzag; select CIRCLE and ring a button; select ARROW and point to the same button.
5. Tap DONE, use the app normally; then select CLEAR, draw a new arrow and tap DONE.
6. Pause for 3 seconds, resume, stop and save.
7. Open the MP4 in Library and seek to the relevant times. Confirm zigzag, circle and arrow appear *inside the video file*, not just live on the screen. Earlier drawings should persist until CLEAR, and later markings should be visible thereafter.
8. Verify speech remains synchronized with the captured app, no upside-down/sideways video, no blackout, no large freezes or missing final frames.
9. Repeat with a longer 1080p recording, test app switching, lock/unlock behavior and Android 14+ capture dialogs. Stop testing if device overheats or recording becomes choppy.

The release build only confirms compilation. The actual device/GPU compositing path cannot be validated by GitHub CI alone.
