# Champak's Screen Recorder — upload key and AAB

The upload key is independent of Champak's Alarm. Preserve its `.jks` and password information privately. Do not commit it to any Git repository or share it in screenshots/messages.

## Safest release flow

1. The GitHub workflow `screenrecorder-release.yml` builds an **unsigned** Android App Bundle using the release variant and Flutter target SDK 36. No keystore is uploaded to GitHub.
2. Download the unsigned AAB from the workflow's Actions artifact.
3. Sign the AAB *locally*, with `jarsigner` from JDK 17+, using the keystore in your offline signing kit:

    `jarsigner -keystore ChampaksScreenRecorderUploadKey.jks -storetype PKCS12 -sigalg SHA256withRSA -digestalg SHA-256 -signedjar app-release-signed.aab app-release-unsigned.aab champaks_screen_recorder_upload`

   Enter the keystore password when prompted. Never pass credentials on the shell command line in shared environments.
4. Verify signing:

    `jarsigner -verify -verbose -certs app-release-signed.aab`

5. Upload `app-release-signed.aab` to Google Play Console **Internal Testing** after creating a separate app with ID `live.learnwithchampak.champaks_screen_recorder`. Do not upload a debug APK.
6. When Google Play enables Play App Signing, the certificate of this dedicated keystore becomes the *upload certificate*. Google Play uses a different signing key for distribution.

The signing kit must be downloaded and backed up before submission; losing it complicates future releases. Do not upload the kit itself to Play Console.
