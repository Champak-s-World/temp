Only public JAR signature records and updated ZIP directory. Contains NO upload private key. Reconstruct using the unsigned AAB from GitHub workflow run 41287512209.
