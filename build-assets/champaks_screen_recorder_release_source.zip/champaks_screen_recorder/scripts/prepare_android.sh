#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v flutter >/dev/null || { echo "Flutter SDK is required (https://docs.flutter.dev/get-started/install)" >&2; exit 1; }
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p "$TMP_DIR/overrides"
cp android/app/src/main/AndroidManifest.xml "$TMP_DIR/overrides/"
cp -R android/app/src/main/kotlin "$TMP_DIR/overrides/"
# The generated Flutter template tracks current Android Gradle Plugin (AGP) versions.
# Do NOT reuse an older custom Android Gradle script: AGP 9 rejects obsolete DSL calls.
# Remove obsolete sample Kotlin sources before Flutter creates the current scaffold.
# Otherwise duplicate MainActivity/Service declarations may be compiled.
rm -rf android/app/src/main/kotlin
rm -f android/app/build.gradle.kts
flutter create --project-name champaks_screen_recorder --platforms android --org live.learnwithchampak .
cp "$TMP_DIR/overrides/AndroidManifest.xml" android/app/src/main/AndroidManifest.xml
mkdir -p android/app/src/main/kotlin
cp -R "$TMP_DIR/overrides/kotlin/." android/app/src/main/kotlin/
python3 - <<'PY'
from pathlib import Path
p=Path('android/app/build.gradle.kts')
s=p.read_text()
for old,new in [('compileSdk = flutter.compileSdkVersion','compileSdk = 36'),
                ('minSdk = flutter.minSdkVersion','minSdk = 29'),
                ('targetSdk = flutter.targetSdkVersion','targetSdk = 36')]:
    if old not in s and new not in s:
        raise SystemExit('Unexpected Flutter Gradle template missing: '+old)
    s=s.replace(old,new)
p.write_text(s)
PY
for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  install -m 644 "branding/ic_launcher_${density}.png" "android/app/src/main/res/mipmap-${density}/ic_launcher.png"
done
flutter pub get
printf 'Android scaffold ready. Run flutter build apk --debug or the signed release workflow.\n'
