package live.learnwithchampak.champaks_screen_recorder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * User-enabled, visible on-screen annotation controls. No Accessibility Service,
 * input monitoring, or hidden capture is used. Drawing mode temporarily takes
 * touch input; Done restores normal interaction with the app beneath.
 */
class AnnotationOverlay(private val context: Context, private val onStop: () -> Unit) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = context.resources.displayMetrics.density
    private fun dp(value: Int) = (density * value + 0.5f).toInt()
    private val canvas = DrawingLayer(context)
    private var started = false
    private var mode = DrawingLayer.Tool.PEN
    private var drawing = false
    private lateinit var toolbar: LinearLayout
    private lateinit var toolbarParams: WindowManager.LayoutParams
    private lateinit var canvasParams: WindowManager.LayoutParams
    private lateinit var modeButton: TextView
    private val toolButtons = mutableMapOf<DrawingLayer.Tool, TextView>()

    fun show() {
        if (started || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        canvasParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; alpha = 0.65f }
        toolbarParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, baseFlags,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(95) }

        toolbar = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(9), dp(7), dp(9), dp(7))
            background = GradientDrawable().apply {
                setColor(Color.argb(241, 22, 39, 62)); cornerRadius = dp(15).toFloat()
            }
            elevation = dp(8).toFloat()
        }
        val title = TextView(context).apply {
            text = "✥  TEACHING TOOLS — drag here"
            setTextColor(Color.WHITE); textSize = 10f
            setPadding(dp(5), 0, dp(5), dp(5))
        }
        toolbar.addView(title)
        var xDown = 0f; var yDown = 0f; var startX = 0; var startY = 0
        title.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { xDown = event.rawX; yDown = event.rawY; startX = toolbarParams.x; startY = toolbarParams.y; true }
                MotionEvent.ACTION_MOVE -> {
                    toolbarParams.x = (startX + event.rawX - xDown).toInt().coerceAtLeast(0)
                    toolbarParams.y = (startY + event.rawY - yDown).toInt().coerceAtLeast(0)
                    wm.updateViewLayout(toolbar, toolbarParams); true
                }
                else -> true
            }
        }
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        toolbar.addView(row)
        fun control(label: String, action: () -> Unit): TextView = TextView(context).apply {
            text = label; textSize = 12f; setTextColor(Color.WHITE)
            setPadding(dp(8), dp(11), dp(8), dp(11))
            background = GradientDrawable().apply {
                setColor(Color.argb(255, 53, 80, 112)); cornerRadius = dp(10).toFloat()
            }
            val layout = LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(3) }
            row.addView(this, layout)
            setOnClickListener { action() }
        }
        modeButton = control("✎ Draw") { setDrawing(!drawing) }
        toolButtons[DrawingLayer.Tool.PEN] = control("Pen") { select(DrawingLayer.Tool.PEN) }
        toolButtons[DrawingLayer.Tool.CIRCLE] = control("○ Circle") { select(DrawingLayer.Tool.CIRCLE) }
        toolButtons[DrawingLayer.Tool.ARROW] = control("➜ Arrow") { select(DrawingLayer.Tool.ARROW) }
        control("⌫ Clear") { canvas.clear() }
        control("■ Stop") { onStop() }
        try {
            wm.addView(canvas, canvasParams)
            wm.addView(toolbar, toolbarParams)
            started = true
            refreshButtons()
        } catch (ex: Exception) {
            try { wm.removeViewImmediate(toolbar) } catch (_: Exception) {}
            try { wm.removeViewImmediate(canvas) } catch (_: Exception) {}
            started = false
            throw ex
        }
    }

    private fun select(chosen: DrawingLayer.Tool) {
        mode = chosen
        canvas.tool = chosen
        setDrawing(true)
    }
    private fun setDrawing(enabled: Boolean) {
        if (!started) return
        drawing = enabled
        canvasParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            (if (drawing) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        // <= 0.8 opacity for an untrusted pass-through overlay on Android 12+.
        canvasParams.alpha = if (drawing) 1f else 0.65f
        wm.updateViewLayout(canvas, canvasParams)
        refreshButtons()
    }
    private fun refreshButtons() {
        if (!started) return
        modeButton.text = if (drawing) "✓ Done" else "✎ Draw"
        toolButtons.forEach { (key, view) ->
            view.setTextColor(if (drawing && key == mode) Color.YELLOW else Color.WHITE)
        }
    }
    fun dismiss() {
        if (!started) return
        started = false
        try { wm.removeViewImmediate(toolbar) } catch (_: Exception) {}
        try { wm.removeViewImmediate(canvas) } catch (_: Exception) {}
    }

    private class DrawingLayer(context: Context) : View(context) {
        enum class Tool { PEN, CIRCLE, ARROW }
        data class Mark(val tool: Tool, val start: PointF, var end: PointF, val path: Path)
        var tool = Tool.PEN
        private val marks = mutableListOf<Mark>()
        private var active: Mark? = null
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.YELLOW; style = Paint.Style.STROKE
            strokeWidth = 6f * resources.displayMetrics.density
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        fun clear() { marks.clear(); active = null; invalidate() }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            val p = PointF(e.x, e.y)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    active = Mark(tool, p, PointF(p.x,p.y), Path().apply { moveTo(p.x,p.y) })
                    invalidate(); return true
                }
                MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                    active?.let {
                        it.end = p
                        if (it.tool == Tool.PEN) it.path.lineTo(p.x,p.y)
                        if (e.actionMasked == MotionEvent.ACTION_UP) {
                            marks.add(it); active = null
                        }
                    }
                    invalidate(); return true
                }
            }
            return true
        }
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            marks.forEach { drawMark(c,it) }
            active?.let { drawMark(c,it) }
        }
        private fun drawMark(c: Canvas, mark: Mark) {
            // Dark outline maintains contrast on bright application backgrounds.
            stroke.color = Color.BLACK; stroke.strokeWidth = 10f * resources.displayMetrics.density
            paintMark(c,mark)
            stroke.color = Color.YELLOW; stroke.strokeWidth = 5f * resources.displayMetrics.density
            paintMark(c,mark)
        }
        private fun paintMark(c: Canvas, mark: Mark) {
            when (mark.tool) {
                Tool.PEN -> c.drawPath(mark.path,stroke)
                Tool.CIRCLE -> c.drawOval(RectF(
                    minOf(mark.start.x, mark.end.x), minOf(mark.start.y, mark.end.y),
                    maxOf(mark.start.x, mark.end.x), maxOf(mark.start.y, mark.end.y)),stroke)
                Tool.ARROW -> {
                    val a = mark.start; val b = mark.end
                    c.drawLine(a.x,a.y,b.x,b.y,stroke)
                    val angle = atan2(b.y-a.y,b.x-a.x)
                    val len=20f*resources.displayMetrics.density
                    val left = angle + 2.55; val right = angle - 2.55
                    c.drawLine(b.x,b.y,b.x+len*cos(left).toFloat(),b.y+len*sin(left).toFloat(),stroke)
                    c.drawLine(b.x,b.y,b.x+len*cos(right).toFloat(),b.y+len*sin(right).toFloat(),stroke)
                }
            }
        }
    }
}
