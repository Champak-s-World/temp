# Champak's Screen Recorder — Privacy Policy

**Effective: 23 October 2026**

Champak's Screen Recorder is an Android app for recording software tutorials. This policy describes the release 1.1.0. The app captures the screen only after the user explicitly accepts the Android screen-recording dialog, and only for that recording session.

**Screen and microphone.** With your consent, the app records the selected screen or app. When you enable voice narration, the app requests microphone permission and includes your voice in the video. You can turn narration off. Recordings may contain sensitive information displayed on your screen; please hide passwords, private notifications and personal information before recording.

**Storage and use.** Recordings are saved locally as MP4 files under the device's Movies/ChampaksScreenRecorder folder, with no automatic cloud upload. The app does not create user accounts and does not use an advertising or analytics SDK in this version. The app does not request Internet access. We do not collect or sell the contents of your recordings.

**Sharing and deletion.** You choose whether to share a recording through Android's share sheet. Other apps or services you choose may handle that file under their own privacy policies. You can rename or delete videos from the app or your device's media manager. Deleting a file on your phone does not delete copies you have already shared elsewhere.

**Permissions.** Screen recording requires the Android system's MediaProjection consent for each session. Optional microphone access is used only if voice narration is enabled. Android may ask permission for notifications so you can see the recording controls. Foreground service permissions keep the recording active and visible when you switch to other apps. Optional floating teaching tools require your explicit approval of Android Draw over other apps access; the on-screen overlay is used solely for visible pen, circle and arrow annotations and does not inspect or collect content from other apps. Android Show taps is a device-level Developer options setting that you can enable manually to highlight where you tap. The app does not request location, contacts or broad storage access.

**Content restrictions.** Android or the application being demonstrated may hide secure screens or prohibit capture. Do not record other people's private information without permission.

**Policy changes.** If future releases add online storage, advertisements, analytics, internal audio recording or other integrations, this policy and the Play Store disclosures will be updated before deployment.

**Developer:** Champak Roy, Programmer's Picnic / Learn With Champak. **Contact and support:** https://www.learnwithchampak.live/p/contact.html. A verified Play Console support email must also be supplied before submission.


Version 1.2.0: Screen recording requires the user to enable Android Draw over other apps special access. A visible REC timer and annotation controls persist while screen recording; the overlay never monitors keystrokes or reads other apps and is removed when recording ends.
