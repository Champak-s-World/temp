#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v flutter >/dev/null || { echo "Flutter SDK is required (https://docs.flutter.dev/get-started/install)" >&2; exit 1; }
ROOT="$(pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p "$TMP_DIR/overrides"
cp android/app/build.gradle.kts "$TMP_DIR/overrides/"
cp android/app/src/main/AndroidManifest.xml "$TMP_DIR/overrides/"
cp -R android/app/src/main/kotlin "$TMP_DIR/overrides/"
flutter create --project-name champaks_screen_recorder --platforms android --org live.learnwithchampak .
cp "$TMP_DIR/overrides/build.gradle.kts" android/app/build.gradle.kts
cp "$TMP_DIR/overrides/AndroidManifest.xml" android/app/src/main/AndroidManifest.xml
cp -R "$TMP_DIR/overrides/kotlin/" android/app/src/main/kotlin/
flutter pub get
printf 'Android scaffold ready. Now run: flutter build apk --debug\n'
