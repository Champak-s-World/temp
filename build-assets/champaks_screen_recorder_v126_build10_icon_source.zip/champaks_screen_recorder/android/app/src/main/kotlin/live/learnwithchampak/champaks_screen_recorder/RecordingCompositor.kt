package live.learnwithchampak.champaks_screen_recorder

import android.graphics.Bitmap
import android.os.SystemClock
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLExt
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Explicitly burns teaching annotations into the H264 video frames.
 *
 * The incoming MediaProjection display goes to a SurfaceTexture (rather than
 * straight into MediaRecorder). A dedicated GLES/EGL thread composites that
 * screen image with a transparent bitmap snapshot of the drawn marks and
 * presents the result to MediaRecorder's input Surface. The microphone and
 * MP4 muxing remain owned by the existing MediaRecorder instance.
 *
 * v1.2.5: Remove our TOP/BOTTOM docked controls from the encoded output.
 * - Default: full-width crop/rescale avoids missing or fabricated content.
 * - Experimental smart repair: cache the unobstructed edge when controls are at
 *   the opposite dock and briefly reuse it; otherwise fall back to safe crop.
 * - App selection: use Android's selected-app capture, no artificial crop.
 * FLAG_SECURE is never used: it caused black recordings on some devices.
 * Smart repair is best effort, never a guarantee of reconstructing moving pixels.
 */
class RecordingCompositor(
    private val encoderSurface: Surface,
    private val width: Int,
    private val height: Int,
    private val reportFailure: (String) -> Unit
) {
    private val thread = HandlerThread("ChampaksVideoCompositor").apply { start() }
    private val handler = Handler(thread.looper)
    private var eglDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface = EGL14.EGL_NO_SURFACE
    private var screenTextureId = 0
    private var marksTextureId = 0
    private var cacheTopId = 0
    private var cacheBottomId = 0
    private var cacheTopAt = 0L
    private var cacheBottomAt = 0L
    private var lastCacheAt = 0L
    private var cropTopPx = 0
    private var cropBottomPx = 0
    private var toolbarDock = "top"
    private var captureScope = "display"
    private var removalMode = "crop"
    private val cacheMaxAgeNs = 1_500_000_000L
    private var texture: SurfaceTexture? = null
    private var inputSurfaceInternal: Surface? = null
    private var screenProgram = 0
    private var marksProgram = 0
    private var marksPresent = false
    private var active = false
    private var closed = false
    private val texMatrix = FloatArray(16)

    // Strip order: lower-left, lower-right, upper-left, upper-right.
    private val vertexData = floatArrayOf(
        -1f, -1f, 0f, 0f,
         1f, -1f, 1f, 0f,
        -1f,  1f, 0f, 1f,
         1f,  1f, 1f, 1f
    )
    private val vertices = ByteBuffer.allocateDirect(vertexData.size * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(vertexData); position(0) }

    val inputSurface: Surface
        get() = requireNotNull(inputSurfaceInternal) { "Compositor is not initialized" }

    init {
        val ready = CountDownLatch(1)
        var failure: Throwable? = null
        handler.post {
            try { createGl() } catch (e: Throwable) { failure = e }
            finally { ready.countDown() }
        }
        if (!ready.await(10, TimeUnit.SECONDS)) {
            thread.quitSafely()
            error("Timed out preparing annotated-video compositor")
        }
        if (failure != null) {
            handler.post { releaseGl() }
            thread.quitSafely()
            throw IllegalStateException("Could not prepare annotated-video compositor", failure)
        }
    }

    private fun createGl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(eglDisplay != EGL14.EGL_NO_DISPLAY) { "EGL display unavailable" }
        val eglVersion = IntArray(2)
        check(EGL14.eglInitialize(eglDisplay, eglVersion, 0, eglVersion, 1)) { "EGL initialization failed" }
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
            0x3142, 1, // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<android.opengl.EGLConfig>(1)
        val count = IntArray(1)
        check(EGL14.eglChooseConfig(eglDisplay, attribs, 0, configs, 0, 1, count, 0) && count[0] > 0) {
            "No recordable GLES2 EGL configuration"
        }
        val contextAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(eglDisplay, configs[0], EGL14.EGL_NO_CONTEXT, contextAttribs, 0)
        check(eglContext != EGL14.EGL_NO_CONTEXT) { "Cannot create GLES2 context" }
        eglSurface = EGL14.eglCreateWindowSurface(
            eglDisplay, configs[0], encoderSurface, intArrayOf(EGL14.EGL_NONE), 0
        )
        check(eglSurface != EGL14.EGL_NO_SURFACE) { "Cannot connect to video encoder surface" }
        check(EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) { "Cannot activate GLES2 encoder context" }

        screenProgram = program(
            VERTEX,
            """#extension GL_OES_EGL_image_external : require
               precision mediump float;
               varying vec2 vTexCoord;
               uniform samplerExternalOES uTexture;
               void main() { gl_FragColor = texture2D(uTexture, vTexCoord); }
            """.trimIndent()
        )
        marksProgram = program(
            VERTEX,
            """precision mediump float;
               varying vec2 vTexCoord;
               uniform sampler2D uTexture;
               void main() { gl_FragColor = texture2D(uTexture, vTexCoord); }
            """.trimIndent()
        )
        val ids = IntArray(4)
        GLES20.glGenTextures(4, ids, 0)
        screenTextureId = ids[0]
        marksTextureId = ids[1]
        cacheTopId = ids[2]
        cacheBottomId = ids[3]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, screenTextureId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, marksTextureId)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        for (id in intArrayOf(cacheTopId, cacheBottomId)) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }

        texture = SurfaceTexture(screenTextureId).apply {
            setDefaultBufferSize(width, height)
            setOnFrameAvailableListener({
                if (closed) return@setOnFrameAvailableListener
                try {
                    // Always dequeue to prevent producer backpressure, even during pause.
                    updateTexImage()
                    if (active) drawFrame()
                } catch (e: Exception) {
                    active = false
                    reportFailure("Annotated video compositor failed: ${e.message ?: "OpenGL error"}")
                }
            }, handler)
        }
        inputSurfaceInternal = Surface(texture)
    }

    fun setActive(value: Boolean) {
        handler.post { if (!closed) active = value }
    }

    /** Capture mode set before MediaProjection starts producing frames. */
    fun configureMode(scope: String, cleanup: String) {
        handler.post {
            captureScope = if (scope == "app") "app" else "display"
            removalMode = if (cleanup == "smart") "smart" else "crop"
        }
    }

    /** Physical screen-space strip sizes converted to encoded frame dimensions. */
    fun updateToolbarBounds(topPx: Int, bottomPx: Int, dock: String) {
        handler.post {
            val changed = toolbarDock != dock
            toolbarDock = if (dock == "bottom") "bottom" else "top"
            cropTopPx = topPx.coerceIn(0, height / 2)
            cropBottomPx = bottomPx.coerceIn(0, height / 2)
            if (changed) lastCacheAt = 0L
        }
    }

    /** Ownership of bitmap transfers to this method and it is recycled after upload. */
    fun updateAnnotations(bitmap: Bitmap) {
        val submitted = handler.post {
            try {
                if (!closed) {
                    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, marksTextureId)
                    GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
                    marksPresent = true // Blank RGBA bitmaps clear old drawings too.
                }
            } catch (e: Exception) {
                reportFailure("Could not write annotations into video: ${e.message ?: "Graphics error"}")
            } finally {
                bitmap.recycle()
            }
        }
        if (!submitted) bitmap.recycle()
    }

    /** Grab a clean screenshot of the OPPOSITE dock's edge for limited repair.
     * Called after drawing the screen but before adding our teaching marks.
     * The cache is refreshed only while its edge is unobscured.
     * GPU copy stays on the EGL thread; no video frames are read into Dart.
     */
    private fun updateCleanEdgeCache(now: Long) {
        if (removalMode != "smart" || captureScope != "display" ||
            now - lastCacheAt < 700_000_000L) return
        lastCacheAt = now
        val id = if (toolbarDock == "top") cacheBottomId else cacheTopId
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
        GLES20.glCopyTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA,
            0, 0, width, height, 0)
        if (toolbarDock == "top") cacheBottomAt = now else cacheTopAt = now
    }

    private fun drawFrame() {
        GLES20.glViewport(0, 0, width, height)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        texture?.getTransformMatrix(texMatrix)
        // First render the actual entire screen. This is also the unmodified
        // source used to cache clean edge regions when controls are elsewhere.
        drawTexture(screenProgram, GLES11Ext.GL_TEXTURE_EXTERNAL_OES, screenTextureId,
            texMatrix, flipOverlay = false)
        val now = SystemClock.elapsedRealtimeNanos()
        updateCleanEdgeCache(now)
        var topFraction = 0f
        var bottomFraction = 0f
        if (captureScope == "display" && (cropTopPx > 0 || cropBottomPx > 0)) {
            val matchingCache = if (toolbarDock == "top") cacheTopId else cacheBottomId
            val matchingTime = if (toolbarDock == "top") cacheTopAt else cacheBottomAt
            val validRepair = removalMode == "smart" && matchingTime > 0L &&
                now - matchingTime in 0..cacheMaxAgeNs
            if (validRepair) {
                // Repair only the covered screen strip with pixels from when
                // that exact area was previously unobstructed. This is a
                // short-lived estimate: it is not perfect for dynamic content.
                val patchHeight = if (toolbarDock == "top") cropTopPx else cropBottomPx
                GLES20.glEnable(GLES20.GL_SCISSOR_TEST)
                GLES20.glScissor(0, if (toolbarDock == "top") height - patchHeight else 0,
                    width, patchHeight)
                drawTexture(marksProgram, GLES20.GL_TEXTURE_2D, matchingCache,
                    IDENTITY, flipOverlay = false)
                GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
            } else {
                // Guaranteed non-black fallback. Remove a full-width edge strip,
                // scale the remaining pixels to the output. This sacrifices
                // part of the screen rather than pretending hidden pixels exist.
                topFraction = cropTopPx.toFloat() / height
                bottomFraction = cropBottomPx.toFloat() / height
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                drawTexture(screenProgram, GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                    screenTextureId, texMatrix, flipOverlay = false,
                    cropTop = topFraction, cropBottom = bottomFraction)
            }
        }
        if (marksPresent) {
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            drawTexture(marksProgram, GLES20.GL_TEXTURE_2D, marksTextureId,
                IDENTITY, flipOverlay = true,
                cropTop = topFraction, cropBottom = bottomFraction)
            GLES20.glDisable(GLES20.GL_BLEND)
        }
        val time = texture?.timestamp ?: System.nanoTime()
        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, time)
        check(EGL14.eglSwapBuffers(eglDisplay, eglSurface)) { "Video encoder surface swap failed" }
    }

    private fun drawTexture(program: Int, target: Int, texId: Int, matrix: FloatArray,
        flipOverlay: Boolean, cropTop: Float = 0f, cropBottom: Float = 0f) {
        GLES20.glUseProgram(program)
        val position = GLES20.glGetAttribLocation(program, "aPosition")
        val texCoord = GLES20.glGetAttribLocation(program, "aTexCoord")
        val transform = GLES20.glGetUniformLocation(program, "uTexMatrix")
        val sampler = GLES20.glGetUniformLocation(program, "uTexture")
        val cropTopUniform = GLES20.glGetUniformLocation(program, "uCropTop")
        val cropBottomUniform = GLES20.glGetUniformLocation(program, "uCropBottom")
        GLES20.glUniform1f(cropTopUniform, cropTop.coerceIn(0f, 0.49f))
        GLES20.glUniform1f(cropBottomUniform, cropBottom.coerceIn(0f, 0.49f))
        vertices.position(0)
        GLES20.glEnableVertexAttribArray(position)
        GLES20.glVertexAttribPointer(position, 2, GLES20.GL_FLOAT, false, 16, vertices)
        // Android Bitmap rows upload top first; flip V for the 2D drawing texture.
        // The OES screen has its own SurfaceTexture transform matrix instead.
        vertices.position(2)
        if (!flipOverlay) {
            GLES20.glEnableVertexAttribArray(texCoord)
            GLES20.glVertexAttribPointer(texCoord, 2, GLES20.GL_FLOAT, false, 16, vertices)
        } else {
            // For the overlay, flip V by supplying a flip matrix. Vertex coordinates
            // remain unchanged so that annotation positions track the displayed app.
            GLES20.glEnableVertexAttribArray(texCoord)
            GLES20.glVertexAttribPointer(texCoord, 2, GLES20.GL_FLOAT, false, 16, vertices)
        }
        GLES20.glUniformMatrix4fv(transform, 1, false, if (flipOverlay) FLIP_V else matrix, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(target, texId)
        GLES20.glUniform1i(sampler, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(position)
        GLES20.glDisableVertexAttribArray(texCoord)
    }

    private fun shader(type: Int, source: String): Int {
        val id = GLES20.glCreateShader(type)
        GLES20.glShaderSource(id, source)
        GLES20.glCompileShader(id)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(id, GLES20.GL_COMPILE_STATUS, ok, 0)
        check(ok[0] != 0) { "GL shader failed: ${GLES20.glGetShaderInfoLog(id)}" }
        return id
    }

    private fun program(vertex: String, fragment: String): Int {
        val vs = shader(GLES20.GL_VERTEX_SHADER, vertex)
        val fs = shader(GLES20.GL_FRAGMENT_SHADER, fragment)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, vs)
        GLES20.glAttachShader(p, fs)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        check(ok[0] != 0) { "GL link failed: ${GLES20.glGetProgramInfoLog(p)}" }
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
        return p
    }

    fun stopFrames() {
        val done = CountDownLatch(1)
        if (!handler.post {
                active = false
                texture?.setOnFrameAvailableListener(null)
                done.countDown()
            }) return
        done.await(3, TimeUnit.SECONDS)
    }

    fun release() {
        val done = CountDownLatch(1)
        if (handler.post {
                closed = true
                releaseGl()
                done.countDown()
            }) done.await(4, TimeUnit.SECONDS)
        thread.quitSafely()
    }

    private fun releaseGl() {
        try { texture?.setOnFrameAvailableListener(null) } catch (_: Exception) {}
        try { inputSurfaceInternal?.release() } catch (_: Exception) {}
        try { texture?.release() } catch (_: Exception) {}
        inputSurfaceInternal = null
        texture = null
        if (eglDisplay != EGL14.EGL_NO_DISPLAY && eglContext != EGL14.EGL_NO_CONTEXT && eglSurface != EGL14.EGL_NO_SURFACE) {
            EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
            if (screenTextureId != 0 && marksTextureId != 0)
                GLES20.glDeleteTextures(4,
                    intArrayOf(screenTextureId, marksTextureId, cacheTopId, cacheBottomId), 0)
            if (screenProgram != 0) GLES20.glDeleteProgram(screenProgram)
            if (marksProgram != 0) GLES20.glDeleteProgram(marksProgram)
            EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        }
        if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
        if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) EGL14.eglTerminate(eglDisplay)
    }

    companion object {
        private val IDENTITY = floatArrayOf(1f,0f,0f,0f, 0f,1f,0f,0f, 0f,0f,1f,0f, 0f,0f,0f,1f)
        private val FLIP_V = floatArrayOf(1f,0f,0f,0f, 0f,-1f,0f,0f, 0f,0f,1f,0f, 0f,1f,0f,1f)
        private const val VERTEX = """attribute vec4 aPosition;
            attribute vec2 aTexCoord;
            uniform mat4 uTexMatrix;
            uniform float uCropTop;
            uniform float uCropBottom;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = aPosition;
                float v = uCropBottom + aTexCoord.y * (1.0 - uCropTop - uCropBottom);
                vTexCoord = (uTexMatrix * vec4(aTexCoord.x,v,0.0,1.0)).xy;
            }
        """
    }
}
