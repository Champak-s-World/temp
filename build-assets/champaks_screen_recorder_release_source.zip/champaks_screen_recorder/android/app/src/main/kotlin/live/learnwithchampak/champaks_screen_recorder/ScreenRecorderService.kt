package live.learnwithchampak.champaks_screen_recorder

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.view.WindowManager
import android.graphics.Point
import kotlin.math.roundToInt

/** Runs only after an explicit Android MediaProjection consent result. */
class ScreenRecorderService : Service() {
    companion object {
        const val START = "live.learnwithchampak.screenrecorder.START"
        const val STOP = "live.learnwithchampak.screenrecorder.STOP"
        const val PAUSE = "live.learnwithchampak.screenrecorder.PAUSE"
        const val RESUME = "live.learnwithchampak.screenrecorder.RESUME"
        const val EVENT = "live.learnwithchampak.screenrecorder.EVENT"
        private const val NOTIFICATION_CHANNEL = "tutorial_screen_recording"
        private const val NOTIFICATION_ID = 13579
        @Volatile var state = "idle"
            private set
        @Volatile var startedAt = 0L
            private set
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var fileDescriptor: ParcelFileDescriptor? = null
    private var savedUri: Uri? = null
    private var isStopping = false
    private var pauseStartedAt = 0L
    private var pausedMs = 0L
    private val mainHandler = Handler(Looper.getMainLooper())
    private var callback: MediaProjection.Callback? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(NOTIFICATION_CHANNEL,
            "Screen recording", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Visible controls while you record a software tutorial"
            setShowBadge(false)
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            START -> {
                if (state != "idle") return START_NOT_STICKY
                state = "starting"
                val mic = intent.getBooleanExtra("microphone", true)
                try {
                    val serviceTypes = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                        if (mic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
                    if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification("Recording starting…"), serviceTypes)
                    else startForeground(NOTIFICATION_ID, notification("Recording starting…"))
                    begin(intent, mic)
                } catch (e: Exception) {
                    announce("error", "Could not start: ${e.message ?: "Unknown error"}")
                    stopRecording(false)
                }
            }
            STOP -> stopRecording(true)
            PAUSE -> {
                if (state == "recording") try {
                    recorder?.pause()
                    pauseStartedAt = SystemClock.elapsedRealtime()
                    announce("paused", "Paused")
                    updateNotification("Recording paused")
                } catch (e: Exception) { announce("error", "Pause failed: ${e.message}") }
            }
            RESUME -> {
                if (state == "paused") try {
                    recorder?.resume()
                    pausedMs += SystemClock.elapsedRealtime() - pauseStartedAt
                    announce("recording", "Recording")
                    updateNotification("Recording your tutorial")
                } catch (e: Exception) { announce("error", "Resume failed: ${e.message}") }
            }
        }
        return START_NOT_STICKY
    }

    private fun begin(intent: Intent, microphone: Boolean) {
        val code = intent.getIntExtra("captureCode", Activity.RESULT_CANCELED)
        val captureIntent = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("captureIntent", Intent::class.java)
        else intent.getParcelableExtra<Intent>("captureIntent")
        require(code == Activity.RESULT_OK && captureIntent != null) { "Missing Android screen consent" }
        val quality = intent.getStringExtra("quality") ?: "1080p"
        val fps = intent.getIntExtra("fps", 30).coerceIn(24, 60)

        val display = (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay
        val physical = Point()
        @Suppress("DEPRECATION")
        display.getRealSize(physical)
        val maxShortEdge = if (quality == "720p") 720 else 1080
        val scale = minOf(1.0, maxShortEdge.toDouble() / minOf(physical.x, physical.y).coerceAtLeast(1))
        // Align each dimension to the encoder-friendly 16 pixel boundary.
        val width = ((physical.x * scale).roundToInt() / 16 * 16).coerceAtLeast(320)
        val height = ((physical.y * scale).roundToInt() / 16 * 16).coerceAtLeast(320)
        val dpi = resources.displayMetrics.densityDpi

        val displayName = "Champaks_Tutorial_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ChampaksScreenRecorder/")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        savedUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Cannot create recording in MediaStore")
        fileDescriptor = contentResolver.openFileDescriptor(savedUri!!, "w")
            ?: error("Cannot open recording output")

        @Suppress("DEPRECATION")
        val mediaRecorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        recorder = mediaRecorder
        if (microphone) mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC)
        mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        mediaRecorder.setVideoSize(width, height)
        mediaRecorder.setVideoFrameRate(fps)
        mediaRecorder.setVideoEncodingBitRate(if (quality == "720p") 4_500_000 else 8_000_000)
        if (microphone) {
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mediaRecorder.setAudioEncodingBitRate(128_000)
            mediaRecorder.setAudioSamplingRate(44100)
        }
        mediaRecorder.setOutputFile(fileDescriptor!!.fileDescriptor)
        mediaRecorder.prepare()

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val activeProjection = manager.getMediaProjection(code, captureIntent)
            ?: error("Android denied screen projection")
        projection = activeProjection
        callback = object : MediaProjection.Callback() {
            override fun onStop() {
                mainHandler.post { if (!isStopping) stopRecording(true) }
            }
        }
        activeProjection.registerCallback(callback!!, mainHandler)
        virtualDisplay = activeProjection.createVirtualDisplay("ChampaksScreenTutorial", width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, mediaRecorder.surface, null, mainHandler)
        mediaRecorder.start()
        startedAt = SystemClock.elapsedRealtime()
        pausedMs = 0L
        announce("recording", "Recording your screen; open Champak's Alarm to demonstrate it")
        updateNotification("Recording your tutorial")
    }

    private fun notification(text: String): Notification {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            ?: Intent(this, MainActivity::class.java)
        val launch = PendingIntent.getActivity(this, 1, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, ScreenRecorderService::class.java).apply { action = STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val pauseAction = if (state == "paused") RESUME else PAUSE
        val pauseTitle = if (state == "paused") "Resume" else "Pause"
        val pause = PendingIntent.getService(this, 3, Intent(this, ScreenRecorderService::class.java).apply { action = pauseAction },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, NOTIFICATION_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Champak's Screen Recorder")
            .setContentText(text)
            .setContentIntent(launch)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(null, pauseTitle, pause).build())
            .addAction(Notification.Action.Builder(null, "Stop and save", stop).build())
            .build()
    }

    private fun updateNotification(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, notification(text))
    }

    private fun announce(nextState: String, message: String = "") {
        state = nextState
        sendBroadcast(Intent(EVENT).setPackage(packageName)
            .putExtra("state", nextState).putExtra("message", message))
    }

    private fun stopRecording(save: Boolean) {
        if (isStopping) return
        isStopping = true
        var good = save && (state == "recording" || state == "paused")
        try {
            if (state == "paused") {
                try { recorder?.resume() } catch (_: Exception) { }
            }
            if (good) {
                try { recorder?.stop() } catch (_: RuntimeException) { good = false }
            }
        } finally {
            try { recorder?.reset() } catch (_: Exception) {}
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            virtualDisplay?.release()
            virtualDisplay = null
            callback?.let { cb -> try { projection?.unregisterCallback(cb) } catch (_: Exception) {} }
            callback = null
            try { projection?.stop() } catch (_: Exception) {}
            projection = null
            try { fileDescriptor?.close() } catch (_: Exception) {}
            fileDescriptor = null
            savedUri?.let { uri ->
                try {
                    if (good) contentResolver.update(uri, ContentValues().apply {
                        put(MediaStore.Video.Media.IS_PENDING, 0)
                    }, null, null)
                    else contentResolver.delete(uri, null, null)
                } catch (_: Exception) { good = false }
            }
            savedUri = null
            startedAt = 0L
            announce("idle", if (good) "Video saved to Movies/ChampaksScreenRecorder" else "Recording stopped without a valid video")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            isStopping = false
        }
    }

    override fun onDestroy() {
        if (state != "idle" && !isStopping) stopRecording(true)
        super.onDestroy()
    }
}
