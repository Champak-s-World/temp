import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const RecorderApp());

class RecorderApp extends StatelessWidget {
  const RecorderApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: "Champak's Screen Recorder",
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0878DB)),
          scaffoldBackgroundColor: const Color(0xFFF1F8FF),
          cardTheme: CardThemeData(
            color: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
        ),
        home: const RecorderHome(),
      );
}

class RecorderHome extends StatefulWidget {
  const RecorderHome({super.key});
  @override
  State<RecorderHome> createState() => _RecorderHomeState();
}

class _RecorderHomeState extends State<RecorderHome> with WidgetsBindingObserver {
  static const native = MethodChannel('live.learnwithchampak.screenrecorder/recorder');
  static const events = EventChannel('live.learnwithchampak.screenrecorder/events');
  final Map<String, Uint8List?> _thumbs = {};
  StreamSubscription<dynamic>? _sub;
  Timer? _ticker;
  int _tab = 0;
  String _state = 'idle';
  String _quality = '1080p';
  int _fps = 30;
  bool _microphone = true;
  bool _autoMinimize = true;
  bool _overlayPermission = false;
  int _elapsedSeconds = 0;
  String _filter = '';
  List<Map<String, dynamic>> _recordings = [];
  bool _loading = false;

  bool get _recording => _state == 'recording' || _state == 'paused';
  bool get _busy => _state == 'starting' || _recording;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkOverlayPermission();
    _openRequestedTab();
    _sub = events.receiveBroadcastStream().listen((event) {
      if (!mounted) return;
      final item = Map<String, dynamic>.from(event as Map);
      final next = (item['state'] ?? 'idle') as String;
      final openLibrary = item['action'] == 'openLibrary';
      setState(() {
        _state = next == 'error' ? 'idle' : next;
        if (_state == 'idle') _elapsedSeconds = 0;
        if (openLibrary || (next == 'idle' && (item['message'] as String? ?? '').startsWith('Saved!'))) _tab = 1;
      });
      final message = item['message'] as String? ?? '';
      if (message.isNotEmpty && (next == 'idle' || next == 'error')) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
      if (next == 'idle') _loadLibrary();
    }, onError: (Object error) => _notice('Event error: $error'));
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _state == 'recording') setState(() => _elapsedSeconds++);
    });
    _loadStatus();
    _loadLibrary();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sub?.cancel();
    _ticker?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkOverlayPermission();
      _loadStatus();
      _loadLibrary();
      _openRequestedTab();
    }
  }

  Future<void> _checkOverlayPermission() async {
    try {
      final allowed = await native.invokeMethod<bool>('overlayPermission') ?? false;
      if (mounted) setState(() => _overlayPermission = allowed);
    } catch (_) {}
  }

  Future<void> _openRequestedTab() async {
    try {
      final tab = await native.invokeMethod<int>('getLaunchTab') ?? 0;
      if (tab == 1 && mounted) setState(() => _tab = 1);
    } catch (_) {}
  }

  Future<void> _tapSettings() async {
    await showDialog<void>(context: context, builder: (c) => AlertDialog(
      title: const Text('Highlight every tap'),
      content: const Text('To show a visible dot wherever you touch while recording:\n\n'
          '1. Open Android Settings → About phone → tap Build number 7 times (if Developer options are hidden).\n'
          '2. Go to Settings → Developer options → Input.\n'
          '3. Turn ON Show taps.\n\n'
          'Android draws the touch dot in your recordings. The recorder cannot switch this system option on silently.'),
      actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Later')),
        FilledButton(onPressed: () { Navigator.pop(c); native.invokeMethod('openTapSettings'); },
            child: const Text('Open settings'))],
    ));
  }

  Future<void> _overlaySettings() async {
    await native.invokeMethod('requestOverlayPermission');
    await _checkOverlayPermission();
  }

  void _showSaveLocation() {
    showDialog<void>(context: context, builder: (c) => AlertDialog(
      title: const Text('Where are videos saved?'),
      content: const Text('Your videos are available in the Library tab.\n\n'
          'In your phone’s Files app, open:\nInternal storage → Movies → ChampaksScreenRecorder\n\n'
          'The folder is created after your first successful recording.'),
      actions: [TextButton(onPressed: () => Clipboard.setData(const ClipboardData(text: 'Movies/ChampaksScreenRecorder')),
          child: const Text('Copy path')),
        FilledButton(onPressed: () { Navigator.pop(c); setState(() => _tab = 1); _loadLibrary(); },
          child: const Text('Open Library'))],
    ));
  }

  Future<void> _loadStatus() async {
    try {
      final status = Map<String, dynamic>.from((await native.invokeMethod('status')) as Map);
      if (mounted) setState(() => _state = status['state'] as String? ?? 'idle');
    } on PlatformException catch (e) { _notice(e.message ?? 'Unable to check recorder'); }
  }

  Future<void> _loadLibrary() async {
    if (_loading) return;
    _loading = true;
    try {
      final rows = (await native.invokeMethod<List<dynamic>>('list')) ?? [];
      if (mounted) setState(() => _recordings = rows.map((e) => Map<String, dynamic>.from(e as Map)).toList());
    } catch (e) { _notice('Unable to load recordings: $e'); }
    finally { _loading = false; }
  }

  Future<void> _command(String method, [Map<String, dynamic>? args]) async {
    try {
      if (method == 'start') setState(() { _state = 'starting'; _elapsedSeconds = 0; });
      await native.invokeMethod(method, args);
    } on PlatformException catch (e) {
      if (method == 'start') setState(() => _state = 'idle');
      _notice(e.message ?? 'The action failed');
    } catch (e) {
      if (method == 'start') setState(() => _state = 'idle');
      _notice('$e');
    }
  }

  void _notice(String text) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _start() async {
    await _checkOverlayPermission();
    if (!_overlayPermission) {
      _notice('Required: Allow Draw over other apps. Recording never starts without the visible toolbar.');
      await _overlaySettings();
      return;
    }
    await _command('start', {
      'quality': _quality, 'fps': _fps, 'microphone': _microphone,
      'autoMinimize': _autoMinimize, 'annotations': true,
    });
  }

  String _duration(int seconds) {
    final h = seconds ~/ 3600;
    final m = (seconds ~/ 60) % 60;
    final s = seconds % 60;
    return h > 0
        ? '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}'
        : '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFF1F8FF),
        title: Row(children: [
          const CircleAvatar(backgroundColor: Color(0xFF0878DB), child: Icon(Icons.videocam_rounded, color: Colors.white)),
          const SizedBox(width: 10),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text("Champak's", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 21)),
            Text('Screen Recorder', style: TextStyle(fontSize: 13, fontWeight: FontWeight.normal)),
          ])),
        ]),
      ),
      body: SafeArea(
        child: switch (_tab) {
          0 => _recordTab(),
          1 => _libraryTab(),
          2 => _guideTab(),
          _ => _settingsTab(),
        },
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (v) {
          setState(() => _tab = v);
          if (v == 1) _loadLibrary();
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.fiber_manual_record_outlined), selectedIcon: Icon(Icons.fiber_manual_record, color: Color(0xFFD92727)), label: 'Record'),
          NavigationDestination(icon: Icon(Icons.video_library_outlined), selectedIcon: Icon(Icons.video_library), label: 'Library'),
          NavigationDestination(icon: Icon(Icons.school_outlined), selectedIcon: Icon(Icons.school), label: 'Guide'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    ),
      if (_state == 'starting') Positioned.fill(
        child: Container(
          color: const Color(0xAA10253A),
          alignment: Alignment.center,
          child: Card(
            margin: const EdgeInsets.symmetric(horizontal: 24),
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const CircularProgressIndicator(),
                const SizedBox(height: 18),
                const Text('Preparing your recording', textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                const Text('Waiting for the red floating REC toolbar to become visible. '
                    'The recording will not begin, and this screen will not minimise, '
                    'until its controls are ready.', textAlign: TextAlign.center),
                const SizedBox(height: 10),
                const Text('If Android asks for screen capture permission, approve it first.',
                    textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                const SizedBox(height: 12),
                OutlinedButton.icon(onPressed: () => _command('stop'),
                    icon: const Icon(Icons.close), label: const Text('Cancel')),
              ]),
            ),
          ),
        ),
      ),
    ]);
  }

  Widget _scroll(List<Widget> children) => ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
        children: [...children, const SizedBox(height: 14),
          const Text('Developed and maintained by Champak Roy',
              textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Color(0xFF667E99)))],
      );

  Widget _card({required Widget child}) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(padding: const EdgeInsets.all(16), child: child),
  );

  Widget _recordTab() => _scroll([
    _card(child: Column(children: [
      Container(
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: const LinearGradient(colors: [Color(0xFF0878DB), Color(0xFF86CEFF)]),
        ),
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Column(children: [
          Icon(_recording ? Icons.radio_button_checked_rounded : Icons.phone_android_rounded,
              size: 65, color: Colors.white),
          const SizedBox(height: 7),
          Text(_recording ? 'Recording in progress' : 'Software tutorial mode',
              style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          Text(_recording ? _duration(_elapsedSeconds) : 'Record an app with your voice',
              style: const TextStyle(color: Colors.white, fontSize: 17)),
        ]),
      ),
      const SizedBox(height: 14),
      const Text('Privacy reminder: recordings may contain messages, passwords or other sensitive information. Hide private notifications before recording. Your videos remain on this device unless you share them.',
        style: TextStyle(fontSize: 12, color: Color(0xFF435D78)), textAlign: TextAlign.center),
      const SizedBox(height: 10),
      TextButton.icon(onPressed: _showSaveLocation, icon: const Icon(Icons.folder_open),
        label: const Text('Where will my video be saved?')) ,
      const SizedBox(height: 16),
      if (!_busy) ...[
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE92D36), minimumSize: const Size(double.infinity, 58)),
          onPressed: _start, icon: const Icon(Icons.fiber_manual_record),
          label: const Text('Start Screen Recording', style: TextStyle(fontSize: 17)),
        ),
        const SizedBox(height: 8),
        const Text('Entire-device recording is requested automatically to capture pop-ups, search windows and other apps. '
            'Android will still ask for permission. The red REC toolbar must appear before recording starts.',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
      ] else if (_state == 'starting') ...[
        const LinearProgressIndicator(),
        const SizedBox(height: 8),
        const Text('Waiting for the floating toolbar to appear…'),
      ] else ...[
        Row(children: [
          Expanded(child: OutlinedButton.icon(
            onPressed: () => _command(_state == 'paused' ? 'resume' : 'pause'),
            icon: Icon(_state == 'paused' ? Icons.play_arrow : Icons.pause),
            label: Text(_state == 'paused' ? 'Resume' : 'Pause'))),
          const SizedBox(width: 10),
          Expanded(child: FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFD92727)),
            onPressed: () => _command('stop'),
            icon: const Icon(Icons.stop), label: const Text('Stop & Save'))),
        ]),
        const SizedBox(height: 8),
        const Text('You can also stop from the Android recording notification.', textAlign: TextAlign.center),
      ],
    ])),
    _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Recording options', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        initialValue: _quality,
        decoration: const InputDecoration(labelText: 'Video resolution', prefixIcon: Icon(Icons.high_quality)),
        items: const [DropdownMenuItem(value: '720p', child: Text('720p — smaller file')),
          DropdownMenuItem(value: '1080p', child: Text('1080p — clear text'))],
        onChanged: _busy ? null : (v) => setState(() => _quality = v ?? '1080p'),
      ),
      const SizedBox(height: 8),
      DropdownButtonFormField<int>(
        initialValue: _fps,
        decoration: const InputDecoration(labelText: 'Frame rate', prefixIcon: Icon(Icons.speed)),
        items: const [DropdownMenuItem(value: 24, child: Text('24 FPS — smaller file')),
          DropdownMenuItem(value: 30, child: Text('30 FPS — recommended')),
          DropdownMenuItem(value: 60, child: Text('60 FPS — smooth'))],
        onChanged: _busy ? null : (v) => setState(() => _fps = v ?? 30),
      ),
      SwitchListTile.adaptive(
        contentPadding: EdgeInsets.zero,
        title: const Text('Narrate with microphone'),
        subtitle: const Text('Explain every action while recording'),
        secondary: const Icon(Icons.mic),
        value: _microphone, onChanged: _busy ? null : (v) => setState(() => _microphone = v),
      ),
      const Divider(),
      SwitchListTile.adaptive(
        contentPadding: EdgeInsets.zero,
        title: const Text('Automatically minimise after toolbar is ready'),
        subtitle: const Text('Only return Home after the floating REC toolbar is confirmed visible and capture begins.'),
        secondary: const Icon(Icons.home_outlined),
        value: _autoMinimize, onChanged: _busy ? null : (v) => setState(() => _autoMinimize = v),
      ),
      const Divider(),
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.visibility, color: Colors.blue),
        title: const Text('ALWAYS-VISIBLE recording toolbar',
            style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(_overlayPermission
            ? 'Enabled. A red REC timer and Pause, Stop, Pen, Circle and Arrow controls stay on screen for the entire recording.'
            : 'Required permission not granted. Recording will not start until Draw over other apps is allowed.'),
        trailing: Icon(_overlayPermission ? Icons.check_circle : Icons.error_outline,
            color: _overlayPermission ? Colors.green : Colors.deepOrange),
        onTap: _overlaySettings,
      ),
      if (!_overlayPermission) FilledButton.icon(
        onPressed: _busy ? null : _overlaySettings,
        icon: const Icon(Icons.security),
        label: const Text('Grant required floating-toolbar permission')),
      OutlinedButton.icon(onPressed: _tapSettings, icon: const Icon(Icons.touch_app),
        label: const Text('Show finger taps in tutorial videos')),
    ])),
    _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Demonstrate Champak\'s Alarm', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Start recording, approve Entire display capture, then open the Alarm app. '
          'New activity windows and app pop-ups will be included, except protected content.'),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: () => _command('openAlarm'),
        icon: const Icon(Icons.alarm), label: const Text("Open Champak's Alarm"),
      ),
      const Text('If Alarm is not installed, this shortcut will show an error. You can demonstrate any other app by opening it normally.',
          style: TextStyle(color: Colors.black54, fontSize: 12)),
    ])),
  ]);

  Widget _libraryTab() {
    final shown = _recordings.where((r) => (r['name'] ?? '').toString().toLowerCase().contains(_filter.toLowerCase())).toList();
    return _scroll([
      _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('My Recordings', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
        const SizedBox(height: 8),
        Text('${_recordings.length} saved video(s)', style: const TextStyle(color: Colors.black54, fontSize: 13)),
        const SizedBox(height: 5),
        const Text('Files → Internal storage → Movies → ChampaksScreenRecorder',
            style: TextStyle(color: Color(0xFF34618E), fontSize: 12)),
        TextButton.icon(onPressed: _showSaveLocation, icon: const Icon(Icons.info_outline),
            label: const Text('How to find videos in Files')),
        const SizedBox(height: 12),
        TextField(
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search recordings', border: OutlineInputBorder()),
          onChanged: (s) => setState(() => _filter = s),
        ),
        Align(alignment: Alignment.centerRight,
            child: TextButton.icon(onPressed: _loadLibrary, icon: const Icon(Icons.refresh), label: const Text('Refresh'))),
      ])),
      if (shown.isEmpty) _card(child: const Padding(
        padding: EdgeInsets.symmetric(vertical: 34),
        child: Column(children: [Icon(Icons.video_library_outlined, size: 56, color: Colors.blueGrey),
          SizedBox(height: 14), Text('No matching recordings yet'),
          SizedBox(height: 6), Text('Start a recording to save your first tutorial.')]),
      )),
      ...shown.map((r) {
        final uri = r['uri'] as String;
        final durationMs = (r['duration'] as num?)?.toInt() ?? 0;
        final sizeMb = ((r['size'] as num?)?.toInt() ?? 0) / 1048576;
        return _card(child: Row(children: [
          FutureBuilder<Uint8List?>(
            future: _thumbnail(uri),
            builder: (context, snap) => ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Container(width: 86, height: 76, color: const Color(0xFFD5EAFA),
                child: snap.hasData && snap.data != null
                    ? Image.memory(snap.data!, fit: BoxFit.cover)
                    : const Icon(Icons.movie, color: Colors.blueGrey)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${r['name']}', maxLines: 2, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
            const SizedBox(height: 3),
            Text('${_duration(durationMs ~/ 1000)}  •  ${sizeMb.toStringAsFixed(1)} MB',
                style: const TextStyle(fontSize: 12, color: Colors.black54)),
            Wrap(spacing: 0, runSpacing: 0, children: [
              IconButton(tooltip: 'Play', icon: const Icon(Icons.play_circle_outline, color: Colors.blue),
                  onPressed: () => _command('play', {'uri': uri})),
              IconButton(tooltip: 'Share', icon: const Icon(Icons.share_outlined),
                  onPressed: () => _command('share', {'uri': uri})),
              IconButton(tooltip: 'Rename', icon: const Icon(Icons.edit_outlined),
                  onPressed: () => _renameDialog(uri, '${r['name']}')),
              IconButton(tooltip: 'Delete', icon: const Icon(Icons.delete_outline, color: Colors.red),
                  onPressed: () => _deleteDialog(uri)),
            ]),
          ])),
        ]));
      }),
    ]);
  }

  Future<Uint8List?> _thumbnail(String uri) async {
    if (_thumbs.containsKey(uri)) return _thumbs[uri];
    try {
      final data = await native.invokeMethod<Uint8List>('thumbnail', {'uri': uri});
      _thumbs[uri] = data;
      return data;
    } catch (_) {
      _thumbs[uri] = null;
      return null;
    }
  }

  Future<void> _renameDialog(String uri, String oldName) async {
    final controller = TextEditingController(text: oldName.replaceFirst(RegExp(r'\.mp4$', caseSensitive: false), ''));
    final name = await showDialog<String>(context: context, builder: (c) => AlertDialog(
      title: const Text('Rename video'),
      content: TextField(controller: controller, autofocus: true,
        decoration: const InputDecoration(labelText: 'Video name')),
      actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(c, controller.text), child: const Text('Rename'))],
    ));
    controller.dispose();
    if (name == null || name.trim().isEmpty) return;
    await _command('rename', {'uri': uri, 'name': name.trim()});
    _loadLibrary();
  }

  Future<void> _deleteDialog(String uri) async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('Delete recording?'),
      content: const Text('This video will be deleted from your phone. This cannot be undone.'),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete'))],
    ));
    if (ok == true) {
      await _command('delete', {'uri': uri});
      _thumbs.remove(uri);
      _loadLibrary();
    }
  }

  Widget _guideTab() => _scroll([
    _card(child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('How to record an app tutorial', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      SizedBox(height: 10),
      Text('Example lesson: How to create and test an alarm in Champak\'s Alarm.'),
    ])),
    ...[
      ('1', 'Prepare your phone', 'Enable Do Not Disturb if suitable, close private chats and turn off notification previews. Do not display passwords or personal information.'),
      ('2', 'Choose your quality', 'Use 1080p / 30 FPS for clear text, and enable the microphone so students hear your explanation.'),
      ('3', 'Start recording', 'Approve Android screen capture and the recorder automatically minimises to Home. Choose Entire screen if you want floating arrows/circles on top of other apps.'),
      ('4', 'Show Champak\'s Alarm', 'Open the app, demonstrate the new alarm button, select a time, configure repeat options and test the alarm. Narrate what students should tap.'),
      ('5', 'Explain taps and annotate', 'The RED REC toolbar remains on top throughout recording and while paused. Choose PEN, CIRCLE or ARROW to annotate; tap DONE to return touches to the app. Tap dots require Android Show taps in Developer options.'),
      ('6', 'Finish safely', 'Use the floating Stop control or Android recording notification to stop and save. A saved notification opens Library.'),
      ('7', 'Review and share', 'Open Library or Files → Internal storage → Movies → ChampaksScreenRecorder. Play, rename or share your MP4.'),
    ].map((step) => _card(child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      CircleAvatar(child: Text(step.$1)), const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(step.$2, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4), Text(step.$3),
      ]))
    ]))),
    _card(child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Important limitations', style: TextStyle(fontWeight: FontWeight.bold)),
      SizedBox(height: 6),
      Text('This release captures the screen and optional microphone narration. Internal sound, face-camera overlays, automatic tap dots without Android Show taps, and video editing are not yet included. Some apps prohibit screen or audio capture. Avoid rotating the screen during a recording.'),
    ])),
  ]);

  void _showPrivacyPolicy() {
    showDialog<void>(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('Privacy policy'),
      content: const SingleChildScrollView(child: Text(
        'Champak\'s Screen Recorder records your phone screen only after you approve the Android capture prompt for each session. When microphone narration is enabled, the app requests microphone permission and records your voice into the video.\n\n'
        'Screen recordings can contain sensitive personal information. Hide private notifications and do not show passwords before recording.\n\n'
        'Videos are saved locally to Movies/ChampaksScreenRecorder. The app has no account, advertising, analytics or internet permission in this version; it does not automatically upload or sell your videos.\n\n'
        'You can play, rename, share or delete recordings. Sharing is entirely at your discretion, and the receiving app may use its own privacy policy.\n\n'
        'A user-approved floating recorder toolbar is required and stays visible throughout the recording. It uses Android Draw over other apps permission, never reads other apps, and closes when recording ends. Tap dots use Android Developer options (Show taps), which the user turns on manually.\n\n'
        'Android may restrict recording of secure apps. Notification permission helps show recording controls and is optional.\n\n'
        'Policy effective 23 October 2026. Developer: Champak Roy, Programmer\'s Picnic / Learn With Champak.'
      )),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Close'))],
    ));
  }

  Widget _settingsTab() => _scroll([
    _card(child: ListTile(leading: const Icon(Icons.touch_app),
      title: const Text('Highlight screen taps'),
      subtitle: const Text('Open Android Developer options → Show taps'),
      onTap: _tapSettings, trailing: const Icon(Icons.chevron_right))),
    _card(child: ListTile(leading: const Icon(Icons.draw),
      title: const Text('Drawing toolbar permission'),
      subtitle: Text(_overlayPermission ? 'Enabled' : 'Tap to allow Draw over other apps'),
      onTap: _overlaySettings, trailing: const Icon(Icons.chevron_right))),
    _card(child: ListTile(leading: const Icon(Icons.folder_outlined),
      title: const Text('Find saved videos'),
      subtitle: const Text('Files → Internal storage → Movies → ChampaksScreenRecorder'),
      onTap: _showSaveLocation, trailing: const Icon(Icons.chevron_right))),
    _card(child: ListTile(
      leading: const Icon(Icons.policy_outlined),
      title: const Text('Privacy policy'),
      subtitle: const Text('Read how screen and microphone recordings are handled'),
      trailing: const Icon(Icons.chevron_right),
      onTap: _showPrivacyPolicy,
    )),
    _card(child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('About the app', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      SizedBox(height: 10),
      ListTile(leading: Icon(Icons.apps), title: Text("Champak's Screen Recorder"), subtitle: Text('Teaching Edition 1.0.0')),
      ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('Privacy by design'),
        subtitle: Text('No account, ads or network permission. Recordings remain on the device unless you choose to share them.')),
      ListTile(leading: Icon(Icons.folder_outlined), title: Text('Video save location'),
        subtitle: Text('Movies/ChampaksScreenRecorder')), 
      ListTile(leading: Icon(Icons.phone_android_outlined), title: Text('Android support'),
        subtitle: Text('Android 10+; built for Android 16 target API.')),
    ])),
    _card(child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('How permissions work', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      SizedBox(height: 8),
      Text('Screen capture: Android requests permission for every session.\n\nMicrophone: requested only if you enable narration.\n\nRecording notification: visible while the foreground recorder operates.\n\nNo accessibility, full storage access, camera, location or internet permissions.'),
    ])),
  ]);
}
