package live.learnwithchampak.champaks_screen_recorder

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.view.WindowManager
import android.graphics.Point
import kotlin.math.roundToInt

/** Runs only after an explicit Android MediaProjection consent result. */
class ScreenRecorderService : Service() {
    companion object {
        const val START = "live.learnwithchampak.screenrecorder.START"
        const val STOP = "live.learnwithchampak.screenrecorder.STOP"
        const val PAUSE = "live.learnwithchampak.screenrecorder.PAUSE"
        const val RESUME = "live.learnwithchampak.screenrecorder.RESUME"
        const val EVENT = "live.learnwithchampak.screenrecorder.EVENT"
        private const val NOTIFICATION_CHANNEL = "tutorial_screen_recording"
        private const val NOTIFICATION_ID = 13579
        @Volatile var state = "idle"
            private set
        @Volatile var startedAt = 0L
            private set
    }

    private var overlay: AnnotationOverlay? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var compositor: RecordingCompositor? = null
    private var videoWidth = 0
    private var videoHeight = 0
    // Collect rapid finger movements into video bitmap updates (~15 FPS).
    private val uploadDrawings = object : Runnable {
        override fun run() {
            if (isStopping) return
            if (state != "recording" && state != "paused") return
            val image = try { overlay?.snapshotAnnotations(videoWidth, videoHeight) }
                        catch (_: Exception) { null }
            if (image != null) compositor?.updateAnnotations(image)
        }
    }
    private fun annotationChanged() {
        mainHandler.removeCallbacks(uploadDrawings)
        mainHandler.postDelayed(uploadDrawings, 65L)
    }
    private var fileDescriptor: ParcelFileDescriptor? = null
    private var savedUri: Uri? = null
    private var isStopping = false
    private var pauseStartedAt = 0L
    private var pausedMs = 0L
    private val mainHandler = Handler(Looper.getMainLooper())
    private var callback: MediaProjection.Callback? = null
    // Fail closed if Android removes the required floating toolbar during a session.
    private val toolbarWatchdog = object : Runnable {
        override fun run() {
            if (isStopping || (state != "recording" && state != "paused")) return
            if (!android.provider.Settings.canDrawOverlays(this@ScreenRecorderService) ||
                overlay?.isVisible() != true) {
                stopRecording(true)
                return
            }
            mainHandler.postDelayed(this, 1500L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(NOTIFICATION_CHANNEL,
            "Screen recording", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Visible controls while you record a software tutorial"
            setShowBadge(false)
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            START -> {
                if (state != "idle") return START_NOT_STICKY
                state = "starting"
                val mic = intent.getBooleanExtra("microphone", true)
                try {
                    val serviceTypes = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                        if (mic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
                    if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification("Recording starting…"), serviceTypes)
                    else startForeground(NOTIFICATION_ID, notification("Recording starting…"))
                    begin(intent, mic)
                } catch (e: Exception) {
                    announce("error", "Could not start: ${e.message ?: "Unknown error"}")
                    stopRecording(false)
                }
            }
            STOP -> stopRecording(true)
            PAUSE -> {
                if (state == "recording") try {
                    recorder?.pause()
                    pauseStartedAt = SystemClock.elapsedRealtime()
                    overlay?.setPaused(true)
                    announce("paused", "Paused")
                    updateNotification("Recording paused")
                } catch (e: Exception) { announce("error", "Pause failed: ${e.message}") }
            }
            RESUME -> {
                if (state == "paused") try {
                    recorder?.resume()
                    pausedMs += SystemClock.elapsedRealtime() - pauseStartedAt
                    overlay?.setPaused(false)
                    announce("recording", "Recording")
                    updateNotification("Recording your tutorial")
                } catch (e: Exception) { announce("error", "Resume failed: ${e.message}") }
            }
        }
        return START_NOT_STICKY
    }

    private fun begin(intent: Intent, microphone: Boolean) {
        val code = intent.getIntExtra("captureCode", Activity.RESULT_CANCELED)
        val captureIntent = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("captureIntent", Intent::class.java)
        else intent.getParcelableExtra<Intent>("captureIntent")
        require(code == Activity.RESULT_OK && captureIntent != null) { "Missing Android screen consent" }
        val quality = intent.getStringExtra("quality") ?: "1080p"
        val fps = intent.getIntExtra("fps", 30).coerceIn(24, 60)
        // Older Android versions have no system single-app chooser.
        val scope = if (Build.VERSION.SDK_INT >= 34 &&
            intent.getStringExtra("captureScope") == "app") "app" else "display"
        val cleanup = intent.getStringExtra("cleanupMode") ?: "crop"
        val toolbarPlacement = intent.getStringExtra("toolbarPlacement") ?: "top"
        val toolbarCollapsed = intent.getBooleanExtra("toolbarCollapsed", false)

        val display = (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay
        val physical = Point()
        @Suppress("DEPRECATION")
        display.getRealSize(physical)
        val maxShortEdge = if (quality == "720p") 720 else 1080
        val scale = minOf(1.0, maxShortEdge.toDouble() / minOf(physical.x, physical.y).coerceAtLeast(1))
        // Align each dimension to the encoder-friendly 16 pixel boundary.
        val width = ((physical.x * scale).roundToInt() / 16 * 16).coerceAtLeast(320)
        val height = ((physical.y * scale).roundToInt() / 16 * 16).coerceAtLeast(320)
        val dpi = resources.displayMetrics.densityDpi
        videoWidth = width
        videoHeight = height

        val displayName = "Champaks_Tutorial_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ChampaksScreenRecorder/")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        savedUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Cannot create recording in MediaStore")
        fileDescriptor = contentResolver.openFileDescriptor(savedUri!!, "w")
            ?: error("Cannot open recording output")

        @Suppress("DEPRECATION")
        val mediaRecorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        recorder = mediaRecorder
        if (microphone) mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC)
        mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        mediaRecorder.setVideoSize(width, height)
        mediaRecorder.setVideoFrameRate(fps)
        mediaRecorder.setVideoEncodingBitRate(if (quality == "720p") 4_500_000 else 8_000_000)
        if (microphone) {
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mediaRecorder.setAudioEncodingBitRate(128_000)
            mediaRecorder.setAudioSamplingRate(44100)
        }
        mediaRecorder.setOutputFile(fileDescriptor!!.fileDescriptor)
        mediaRecorder.prepare()

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val activeProjection = manager.getMediaProjection(code, captureIntent)
            ?: error("Android denied screen projection")
        projection = activeProjection
        callback = object : MediaProjection.Callback() {
            override fun onStop() {
                mainHandler.post { if (!isStopping) stopRecording(true) }
            }
        }
        activeProjection.registerCallback(callback!!, mainHandler)
        // A projection overlay window is not reliably recorded by Android. Draw our
        // vector annotations into the H264 frames before MediaRecorder receives them.
        val gl = RecordingCompositor(mediaRecorder.surface, width, height) { failure ->
            mainHandler.post {
                if (!isStopping && state != "idle") {
                    announce("error", failure)
                    stopRecording(false)
                }
            }
        }
        compositor = gl
        gl.configureMode(scope, cleanup)
        virtualDisplay = activeProjection.createVirtualDisplay("ChampaksScreenTutorial", width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, gl.inputSurface, null, mainHandler)
        // Android attaches WindowManager views asynchronously. Calling isAttachedToWindow
        // immediately after addView() returns a false negative on many phones.
        // Never start the encoder until the mandatory toolbar has really attached.
        require(android.provider.Settings.canDrawOverlays(this)) {
            "Allow Draw over other apps for the always-visible recording toolbar"
        }
        var toolbarGeometryReady = false
        val candidate = AnnotationOverlay(
            this,
            onStop = { stopRecording(true) },
            onPauseResume = {
                val command = if (state == "paused") RESUME else PAUSE
                startService(Intent(this, ScreenRecorderService::class.java).apply { action = command })
            },
            onAnnotationsChanged = { annotationChanged() },
            initialDock = toolbarPlacement,
            initiallyCollapsed = toolbarCollapsed,
            onToolbarBoundsChanged = { topPhysical, bottomPhysical, dock ->
                val top = (topPhysical.toLong() * height / physical.y.coerceAtLeast(1)).toInt()
                val bottom = (bottomPhysical.toLong() * height / physical.y.coerceAtLeast(1)).toInt()
                gl.updateToolbarBounds(top, bottom, dock)
                toolbarGeometryReady = true
            },
            onToolbarMoving = {
                // Do not encode the momentary intermediate position: it could
                // expose controls before the new top/bottom crop takes effect.
                if (state == "recording") gl.setActive(false)
            },
            onToolbarSettled = {
                if (state == "recording" && !isStopping) gl.setActive(true)
            }
        )
        overlay = candidate
        candidate.show()
        announce("starting", "Waiting until the floating REC toolbar is visible…")
        updateNotification("Waiting for visible floating REC controls…")

        // Block startup until the toolbar has a real window token, complete layout,
        // and has remained visible across several consecutive checks.  A brief
        // attachment is not enough: Android's overlay surface can be deferred
        // for several frames after the screen-capture permission dialog.
        // Allow up to 12 seconds, then fail safely instead of capturing unseen.
        var checks = 0
        var stableChecks = 0
        val awaitToolbar = object : Runnable {
            override fun run() {
                if (isStopping || state != "starting") return
                if (!android.provider.Settings.canDrawOverlays(this@ScreenRecorderService)) {
                    failToolbar("Draw over other apps permission was revoked")
                    return
                }
                stableChecks = if (candidate.isReadyToRecord() && toolbarGeometryReady)
                    stableChecks + 1 else 0
                if (stableChecks >= 5) {
                    try {
                        mediaRecorder.start()
                        compositor?.setActive(true)
                        candidate.markRecordingStarted()
                        startedAt = SystemClock.elapsedRealtime()
                        pausedMs = 0L
                        // Now the toolbar and encoder are BOTH active.
                        announce("recording", "Recording started — toolbar visible; clean export enabled")
                        mainHandler.postDelayed(toolbarWatchdog, 1500L)
                        updateNotification("Recording your tutorial • Movies/ChampaksScreenRecorder")
                    } catch (e: Exception) {
                        failToolbar("Recorder could not start: ${e.message ?: "Unknown error"}")
                    }
                    return
                }
                checks++
                if (checks >= 120) {
                    failToolbar("Floating toolbar was not ready within 12 seconds. Check Display over other apps permission and disable battery restrictions for this app, then retry")
                } else mainHandler.postDelayed(this, 100L)
            }
        }
        mainHandler.postDelayed(awaitToolbar, 100L)
    }

    private fun failToolbar(message: String) {
        if (isStopping) return
        announce("error", message)
        stopRecording(false)
    }

    private fun notification(text: String): Notification {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            ?: Intent(this, MainActivity::class.java)
        val launch = PendingIntent.getActivity(this, 1, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, ScreenRecorderService::class.java).apply { action = STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val pauseAction = if (state == "paused") RESUME else PAUSE
        val pauseTitle = if (state == "paused") "Resume" else "Pause"
        val pause = PendingIntent.getService(this, 3, Intent(this, ScreenRecorderService::class.java).apply { action = pauseAction },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, NOTIFICATION_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Champak's Screen Recorder")
            .setContentText(text)
            .setContentIntent(launch)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(null, pauseTitle, pause).build())
            .addAction(Notification.Action.Builder(null, "Stop and save", stop).build())
            .build()
    }

    private fun notifySaved() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel("saved_tutorials",
            "Saved recordings", NotificationManager.IMPORTANCE_DEFAULT))
        val open = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("openLibrary", true)
        }
        val click = PendingIntent.getActivity(this, 22, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val note = Notification.Builder(this, "saved_tutorials")
            .setSmallIcon(android.R.drawable.ic_menu_save)
            .setContentTitle("Tutorial saved successfully")
            .setContentText("Tap to open Library • Movies/ChampaksScreenRecorder")
            .setStyle(Notification.BigTextStyle().bigText(
                "Your video is in Library and Files → Internal storage → Movies → ChampaksScreenRecorder"))
            .setContentIntent(click).setAutoCancel(true).build()
        try { manager.notify(13580, note) } catch (_: SecurityException) {
            // Users who deny notification permission can still find the saved video in Library.
        }
    }

    private fun updateNotification(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, notification(text))
    }

    private fun announce(nextState: String, message: String = "") {
        state = nextState
        sendBroadcast(Intent(EVENT).setPackage(packageName)
            .putExtra("state", nextState).putExtra("message", message))
    }

    private fun stopRecording(save: Boolean) {
        if (isStopping) return
        isStopping = true
        mainHandler.removeCallbacks(toolbarWatchdog)
        mainHandler.removeCallbacks(uploadDrawings)
        try { compositor?.stopFrames() } catch (_: Exception) {}
        var good = save && (state == "recording" || state == "paused")
        try {
            if (state == "paused") {
                try { recorder?.resume() } catch (_: Exception) { }
            }
            if (good) {
                try { recorder?.stop() } catch (_: RuntimeException) { good = false }
            }
        } finally {
            virtualDisplay?.release()
            virtualDisplay = null
            try { compositor?.release() } catch (_: Exception) {}
            compositor = null
            try { recorder?.reset() } catch (_: Exception) {}
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            callback?.let { cb -> try { projection?.unregisterCallback(cb) } catch (_: Exception) {} }
            callback = null
            try { projection?.stop() } catch (_: Exception) {}
            projection = null
            try { fileDescriptor?.close() } catch (_: Exception) {}
            fileDescriptor = null
            savedUri?.let { uri ->
                try {
                    if (good) contentResolver.update(uri, ContentValues().apply {
                        put(MediaStore.Video.Media.IS_PENDING, 0)
                    }, null, null)
                    else contentResolver.delete(uri, null, null)
                } catch (_: Exception) { good = false }
            }
            overlay?.dismiss()
            overlay = null
            savedUri = null
            startedAt = 0L
            announce("idle", if (good) "Saved! Find it in Library or Movies/ChampaksScreenRecorder." else "Recording stopped without a valid video")
            if (good) notifySaved()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            isStopping = false
        }
    }

    override fun onDestroy() {
        if (state != "idle" && !isStopping) stopRecording(true)
        super.onDestroy()
    }
}
